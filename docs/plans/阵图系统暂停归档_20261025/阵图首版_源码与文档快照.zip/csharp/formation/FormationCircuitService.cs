using Godot;
using Godot.Collections;
using System;
using System.Collections.Generic;
using System.Linq;

/// <summary>首版阵图的结构校验、角色资格校验、深复制与原子装配服务。</summary>
public static class FormationCircuitService
{
    public static FormationCircuitData CloneForEditing(FormationCircuitData source)
    {
        ArgumentNullException.ThrowIfNull(source);
        var clone = new FormationCircuitData
        {
            circuit_id = source.circuit_id,
            circuit_name = source.circuit_name,
            description = source.description,
            required_formation_proficiency = source.required_formation_proficiency,
            hardware = source.hardware is null ? null : CloneHardware(source.hardware),
            required_manual_ids = CloneStrings(source.required_manual_ids),
            nodes = new Array<FormationNodeData>(),
            pulse_wires = new Array<FormationWireData>()
        };

        foreach (var node in source.nodes ?? new Array<FormationNodeData>())
            clone.nodes.Add(node is null ? null! : CloneNodeForEditing(node));
        foreach (var wire in source.pulse_wires ?? new Array<FormationWireData>())
            clone.pulse_wires.Add(wire is null ? null! : CloneWire(wire));
        return clone;
    }

    /// <summary>复制角色阵图清单及所有 Resource 子节点，不与来源共享可编辑对象。</summary>
    public static Array<FormationCircuitData> CloneCircuits(IEnumerable<FormationCircuitData> circuits)
    {
        var result = new Array<FormationCircuitData>();
        if (circuits is null) return result;
        foreach (var circuit in circuits)
            result.Add(circuit is null ? null! : CloneForEditing(circuit));
        return result;
    }

    internal static FormationNodeData CloneNodeForEditing(FormationNodeData source)
    {
        ArgumentNullException.ThrowIfNull(source);
        return new FormationNodeData
        {
            node_id = source.node_id,
            display_name = source.display_name,
            kind = source.kind,
            input_event = source.input_event,
            accepted_source_tags = CloneStrings(source.accepted_source_tags),
            minimum_amplitude = source.minimum_amplitude,
            interval = source.interval,
            energy_cost = source.energy_cost,
            peak_load = source.peak_load,
            priority = source.priority,
            effect_value = source.effect_value,
            actuator_effect = source.actuator_effect,
            once_per_owner_turn = source.once_per_owner_turn,
            required_material_tags = CloneStrings(source.required_material_tags),
            editor_position = source.editor_position,
            has_editor_position = source.has_editor_position
        };
    }

    public static FormationValidationResult Validate(
        FormationCircuitData draft,
        float proficiency,
        IEnumerable<string> manualIds)
    {
        var issues = new List<FormationValidationIssue>();
        void Add(string code, string message, string nodeId = "", string from = "", string to = "") =>
            issues.Add(new FormationValidationIssue
            {
                Code = code,
                Message = message,
                NodeId = nodeId,
                FromNodeId = from,
                ToNodeId = to
            });

        if (draft is null)
        {
            Add("invalid_node", "阵图草稿为空");
            return new FormationValidationResult { Issues = issues, Metrics = new FormationCircuitMetrics() };
        }

        var metrics = Measure(draft);
        if (draft.circuit_id.ToString() != FormationV1Catalog.CircuitId)
            Add("invalid_node", $"首版只允许编辑阵图 {FormationV1Catalog.CircuitId}");

        var sourceNodes = draft.nodes ?? new Array<FormationNodeData>();
        var nodes = sourceNodes.Where(node => node is not null).ToList();
        if (nodes.Count != sourceNodes.Count)
            Add("invalid_node", "阵图包含空元件记录");

        var nodesById = new System.Collections.Generic.Dictionary<string, FormationNodeData>(StringComparer.Ordinal);
        foreach (var node in nodes)
        {
            var id = node.node_id.ToString();
            if (string.IsNullOrWhiteSpace(id))
            {
                Add("invalid_node", "阵图存在没有稳定 ID 的元件");
                continue;
            }
            if (!nodesById.TryAdd(id, node))
                Add("invalid_node", $"元件 ID 重复：{id}", id);
            if (!FormationV1Catalog.IsKnownNodeId(id))
            {
                Add("invalid_node", $"首版目录不包含元件：{id}", id);
                continue;
            }

            var expected = FormationV1Catalog.GetTemplateNode(id);
            if (!MatchesTemplateSemantics(node, expected))
                Add("invalid_node", $"元件 {id} 的固定配置与首版模板不符", id);
        }

        var hasInput = nodesById.ContainsKey(FormationV1Catalog.InputNodeId);
        var hasCounter = nodesById.ContainsKey(FormationV1Catalog.CounterNodeId);
        var hasActuator = nodesById.ContainsKey(FormationV1Catalog.ActuatorNodeId);
        var hasUnknown = nodesById.Keys.Any(id => !FormationV1Catalog.IsKnownNodeId(id));
        var expectedNodeCount = hasCounter ? 3 : 2;
        var validNodeShape = hasInput && hasActuator && !hasUnknown
                             && nodesById.Count == expectedNodeCount;
        if (!validNodeShape)
            Add("invalid_node", "合法阵图必须是感应→护持，或感应→三候→护持；每类元件最多一份");

        ValidateWires(draft, nodesById, validNodeShape, hasCounter, Add);
        ValidateManualPorts(nodesById, Add);

        var hardware = draft.hardware;
        if (hardware is null)
        {
            Add("invalid_hardware", "阵图缺少阵盘、阵眼、阵源或灵络硬件配置");
        }
        else
        {
            if (hardware.component_slots < 0 || hardware.pulse_layers < 0 || hardware.eye_complexity < 0
                || hardware.source_capacity < 0 || hardware.source_recharge_per_turn < 0
                || hardware.source_peak_output < 0 || hardware.spirit_link_peak_output < 0
                || hardware.board_peak_load < 0)
                Add("invalid_hardware", "硬件参数不能为负数");
            if (hardware.pulse_layers == 0 && (draft.pulse_wires?.Count ?? 0) > 0)
                Add("invalid_hardware", "存在脉纹时，硬件至少需要一层脉纹承载");

            if (metrics.UsedSlots > metrics.SlotCapacity)
                Add("slots", $"格位不足：需要 {metrics.UsedSlots}，当前 {metrics.SlotCapacity}");
            if (metrics.Complexity > metrics.ComplexityCapacity)
                Add("complexity", $"阵眼复杂度不足：需要 {metrics.Complexity}，当前 {metrics.ComplexityCapacity}");
        }

        ValidateQualifications(nodesById.Keys, proficiency, manualIds, Add);

        return new FormationValidationResult { Issues = issues, Metrics = metrics };
    }

    /// <summary>校验单个目录元件能否使用，不要求它已经组成完整阵图。</summary>
    public static System.Collections.Generic.IReadOnlyList<FormationValidationIssue> ValidateNodeAccess(
        string nodeId,
        float proficiency,
        IEnumerable<string> manualIds)
    {
        var issues = new List<FormationValidationIssue>();
        void Add(string code, string message, string issueNodeId = "", string from = "", string to = "") =>
            issues.Add(new FormationValidationIssue
            {
                Code = code,
                Message = message,
                NodeId = issueNodeId,
                FromNodeId = from,
                ToNodeId = to
            });

        if (!FormationV1Catalog.IsKnownNodeId(nodeId))
        {
            Add("invalid_node", $"首版目录不包含元件：{nodeId}", nodeId);
            return issues;
        }

        var expectedNode = FormationV1Catalog.GetTemplateNode(nodeId);
        var nodeById = new System.Collections.Generic.Dictionary<string, FormationNodeData>(StringComparer.Ordinal)
        {
            [nodeId] = expectedNode
        };
        ValidateManualPorts(nodeById, Add);
        ValidateQualifications(new[] { nodeId }, proficiency, manualIds, Add);
        return issues;
    }

    public static bool TryApply(HumanData owner, FormationCircuitData draft, out FormationValidationResult result)
    {
        if (owner is null)
        {
            result = new FormationValidationResult
            {
                Issues = new[]
                {
                    new FormationValidationIssue { Code = "invalid_owner", Message = "没有可装配阵图的角色" }
                }
            };
            return false;
        }

        result = Validate(draft, owner.formation_proficiency, owner.formation_manual_ids);
        if (!result.IsValid) return false;

        var replacement = CloneForEditing(draft);
        replacement.required_formation_proficiency = result.Metrics.RequiredProficiency;
        replacement.required_manual_ids = ToGodotStrings(RequiredManualIdsFor(draft));

        // 构造完整新列表后一次赋回；同 ID 的旧记录折叠为一条，其他阵图原样保留。
        var updated = new Array<FormationCircuitData>();
        var inserted = false;
        foreach (var existing in owner.formation_circuits ?? new Array<FormationCircuitData>())
        {
            if (existing is not null && existing.circuit_id.ToString() == FormationV1Catalog.CircuitId)
            {
                if (!inserted) updated.Add(replacement);
                inserted = true;
            }
            else
            {
                updated.Add(existing!);
            }
        }
        if (!inserted) updated.Add(replacement);
        owner.formation_circuits = updated;
        return true;
    }

    internal static string[] RequiredManualIdsFor(FormationCircuitData circuit)
    {
        if (circuit is null) return System.Array.Empty<string>();
        var ids = new List<string>();
        foreach (var node in circuit.nodes ?? new Array<FormationNodeData>())
        {
            if (node is null) continue;
            var manualId = RequiredManualIdForNode(node.node_id.ToString());
            if (manualId.Length > 0 && !ids.Contains(manualId, StringComparer.Ordinal)) ids.Add(manualId);
        }
        return ids.ToArray();
    }

    private static void ValidateQualifications(
        IEnumerable<string> nodeIds,
        float proficiency,
        IEnumerable<string>? manualIds,
        Action<string, string, string, string, string> add)
    {
        var actualNodeIds = nodeIds.Where(FormationV1Catalog.IsKnownNodeId)
            .Distinct(StringComparer.Ordinal)
            .ToArray();
        var requiredManuals = actualNodeIds
            .Select(RequiredManualIdForNode)
            .Where(id => id.Length > 0)
            .Distinct(StringComparer.Ordinal);
        var ownedManuals = new HashSet<string>(StringComparer.Ordinal);
        if (manualIds is not null)
            foreach (var manualId in manualIds)
                if (!string.IsNullOrWhiteSpace(manualId)) ownedManuals.Add(manualId);
        foreach (var manualId in requiredManuals)
            if (!ownedManuals.Contains(manualId))
                add("missing_manual", $"缺少所需阵法录：《{ManualDisplayName(manualId)}》", "", "", "");

        var requiredProficiency = actualNodeIds
            .Select(FormationV1Catalog.RequiredProficiency)
            .DefaultIfEmpty(0.0f)
            .Max();
        if (!float.IsFinite(proficiency) || proficiency < requiredProficiency)
            add("proficiency", $"阵道造诣不足：需要 {requiredProficiency:0}，当前 {proficiency:0.##}", "", "", "");
    }

    private static string RequiredManualIdForNode(string nodeId) => nodeId switch
    {
        FormationV1Catalog.InputNodeId => FormationV1Catalog.InputManualId,
        FormationV1Catalog.ActuatorNodeId => FormationV1Catalog.OutputManualId,
        _ => ""
    };

    private static string ManualDisplayName(string manualId) => manualId switch
    {
        FormationV1Catalog.InputManualId => FormationV1Catalog.LoadInputManual().manual_name,
        FormationV1Catalog.OutputManualId => FormationV1Catalog.LoadOutputManual().manual_name,
        _ => manualId
    };

    private static FormationCircuitMetrics Measure(FormationCircuitData draft)
    {
        var usedSlots = 0;
        var complexity = 0;
        foreach (var node in draft.nodes ?? new Array<FormationNodeData>())
        {
            if (node is null) continue;
            usedSlots += node.kind switch
            {
                FormationNodeData.NodeKind.INPUT or FormationNodeData.NodeKind.ACTUATOR => 1,
                FormationNodeData.NodeKind.COUNTER => 2,
                _ => 0
            };
            complexity += node.complexity_cost();
        }

        var hardware = draft.hardware;
        var requiredProficiency = (draft.nodes ?? new Array<FormationNodeData>())
            .Where(node => node is not null)
            .Select(node =>
            {
                var id = node.node_id.ToString();
                return FormationV1Catalog.IsKnownNodeId(id) ? FormationV1Catalog.RequiredProficiency(id) : 0.0f;
            })
            .DefaultIfEmpty(0.0f)
            .Max();

        return new FormationCircuitMetrics
        {
            UsedSlots = usedSlots,
            SlotCapacity = hardware?.effective_component_slots() ?? 0,
            Complexity = complexity,
            ComplexityCapacity = hardware?.effective_eye_complexity() ?? 0,
            SourceCapacity = hardware?.effective_source_capacity() ?? 0,
            SourceRechargePerRound = hardware?.effective_source_recharge() ?? 0,
            SourcePeak = hardware?.effective_source_peak() ?? 0,
            LinkPeak = hardware?.effective_link_peak() ?? 0,
            BoardLoad = hardware?.effective_board_load() ?? 0,
            RequiredProficiency = requiredProficiency
        };
    }

    private static void ValidateWires(
        FormationCircuitData draft,
        System.Collections.Generic.Dictionary<string, FormationNodeData> nodesById,
        bool validNodeShape,
        bool hasCounter,
        Action<string, string, string, string, string> add)
    {
        var edges = new HashSet<(string From, string To)>();
        var adjacency = nodesById.Keys.ToDictionary(id => id, _ => new List<string>(), StringComparer.Ordinal);
        foreach (var wire in draft.pulse_wires ?? new Array<FormationWireData>())
        {
            if (wire is null)
            {
                add("invalid_wire", "阵图包含空脉纹记录", "", "", "");
                continue;
            }

            var from = wire.from_node_id.ToString();
            var to = wire.to_node_id.ToString();
            if (!nodesById.ContainsKey(from) || !nodesById.ContainsKey(to) || from.Length == 0 || to.Length == 0)
            {
                add("invalid_wire", $"脉纹连接了不存在的元件：{from} → {to}", "", from, to);
                continue;
            }
            if (from == to)
            {
                add("cycle", $"脉纹不能回接自身：{from}", from, from, to);
                continue;
            }
            if (!edges.Add((from, to)))
            {
                add("invalid_wire", $"脉纹重复：{from} → {to}", "", from, to);
                continue;
            }
            adjacency[from].Add(to);
        }

        if (ContainsCycle(adjacency)) add("cycle", "脉纹形成回路，首版不允许反馈线路", "", "", "");
        if (!validNodeShape) return;

        var input = FormationV1Catalog.InputNodeId;
        var counter = FormationV1Catalog.CounterNodeId;
        var actuator = FormationV1Catalog.ActuatorNodeId;
        var expected = hasCounter
            ? new[] { (input, counter), (counter, actuator) }
            : new[] { (input, actuator) };

        foreach (var edge in edges)
            if (!expected.Contains(edge))
                add("invalid_wire", $"首版不允许此脉纹：{edge.Item1} → {edge.Item2}", "", edge.Item1, edge.Item2);
        foreach (var edge in expected)
            if (!edges.Contains(edge))
                add("disconnected", $"线路未连通：{edge.Item1} → {edge.Item2}", "", edge.Item1, edge.Item2);

        var reached = new HashSet<string>(StringComparer.Ordinal);
        var pending = new Stack<string>();
        pending.Push(input);
        while (pending.Count > 0)
        {
            var current = pending.Pop();
            if (!reached.Add(current)) continue;
            foreach (var next in adjacency[current]) pending.Push(next);
        }
        if (!reached.Contains(actuator) || reached.Count != nodesById.Count)
            add("disconnected", "所有元件必须处于从感应枢到护持阵器的同一条脉纹链路上", "", "", "");
    }

    private static bool ContainsCycle(System.Collections.Generic.Dictionary<string, List<string>> adjacency)
    {
        var state = new System.Collections.Generic.Dictionary<string, byte>(StringComparer.Ordinal);
        bool Visit(string node)
        {
            if (state.TryGetValue(node, out var current)) return current == 1;
            state[node] = 1;
            foreach (var next in adjacency[node])
                if (Visit(next)) return true;
            state[node] = 2;
            return false;
        }

        foreach (var node in adjacency.Keys)
            if (Visit(node)) return true;
        return false;
    }

    private static void ValidateManualPorts(
        System.Collections.Generic.Dictionary<string, FormationNodeData> nodesById,
        Action<string, string, string, string, string> add)
    {
        if (nodesById.ContainsKey(FormationV1Catalog.InputNodeId))
        {
            var manual = FormationV1Catalog.LoadInputManual();
            var input = manual?.input_ports?.FirstOrDefault(port => port is not null && port.port_id.ToString() == "port_spell_played");
            var valid = manual?.manual_id.ToString() == FormationV1Catalog.InputManualId
                        && input is not null
                        && input.kind == FormationPortData.PortKind.INPUT
                        && input.battle_event == "spell_played"
                        && input.source_tags?.Contains("spell") == true;
            if (!valid)
                add("invalid_port", "小周天阵录缺少真实的 spell_played 输入端口", FormationV1Catalog.InputNodeId, "", "");
        }

        if (nodesById.TryGetValue(FormationV1Catalog.ActuatorNodeId, out var actuator))
        {
            var manual = FormationV1Catalog.LoadOutputManual();
            var output = manual?.output_ports?.FirstOrDefault(port => port is not null && port.port_id.ToString() == "port_guard_ward");
            var valid = manual?.manual_id.ToString() == FormationV1Catalog.OutputManualId
                        && output is not null
                        && output.kind == FormationPortData.PortKind.OUTPUT
                        && output.actuator_effect == FormationNodeData.ActuatorEffect.SHIELD
                        && output.minimum_energy_cost == actuator.energy_cost
                        && SequenceEqualSafe(output.required_material_tags, actuator.required_material_tags);
            if (!valid)
                add("invalid_port", "护元阵录缺少与模板一致的真实护持输出端口", FormationV1Catalog.ActuatorNodeId, "", "");
        }
    }

    private static bool MatchesTemplateSemantics(FormationNodeData actual, FormationNodeData expected) =>
        actual.node_id == expected.node_id
        && actual.display_name == expected.display_name
        && actual.kind == expected.kind
        && actual.input_event == expected.input_event
        && SequenceEqualSafe(actual.accepted_source_tags, expected.accepted_source_tags)
        && actual.minimum_amplitude == expected.minimum_amplitude
        && actual.interval == expected.interval
        && actual.energy_cost == expected.energy_cost
        && actual.peak_load == expected.peak_load
        && actual.priority == expected.priority
        && actual.effect_value == expected.effect_value
        && actual.actuator_effect == expected.actuator_effect
        && actual.once_per_owner_turn == expected.once_per_owner_turn
        && SequenceEqualSafe(actual.required_material_tags, expected.required_material_tags);

    private static bool SequenceEqualSafe<T>(IEnumerable<T>? left, IEnumerable<T>? right) =>
        left is not null && right is not null && left.SequenceEqual(right);

    private static FormationHardwareData CloneHardware(FormationHardwareData source) => new()
    {
        component_slots = source.component_slots,
        pulse_layers = source.pulse_layers,
        eye_complexity = source.eye_complexity,
        source_capacity = source.source_capacity,
        source_recharge_per_turn = source.source_recharge_per_turn,
        source_peak_output = source.source_peak_output,
        spirit_link_peak_output = source.spirit_link_peak_output,
        board_peak_load = source.board_peak_load,
        board_material_tags = CloneStrings(source.board_material_tags),
        ink_material_tags = CloneStrings(source.ink_material_tags),
        eye_material_tags = CloneStrings(source.eye_material_tags),
        source_material_tags = CloneStrings(source.source_material_tags)
    };

    private static FormationWireData CloneWire(FormationWireData source) => new()
    {
        from_node_id = source.from_node_id,
        to_node_id = source.to_node_id
    };

    private static Array<string> CloneStrings(IEnumerable<string> source)
    {
        var result = new Array<string>();
        if (source is null) return result;
        foreach (var value in source) result.Add(value);
        return result;
    }

    private static Array<string> ToGodotStrings(IEnumerable<string> source) => CloneStrings(source);
}
