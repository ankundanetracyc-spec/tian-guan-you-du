public sealed class FormationValidationIssue
{
    public string Code { get; init; } = "";
    public string Message { get; init; } = "";
    public string NodeId { get; init; } = "";
    public string FromNodeId { get; init; } = "";
    public string ToNodeId { get; init; } = "";
}

public sealed class FormationCircuitMetrics
{
    public int UsedSlots { get; init; }
    public int SlotCapacity { get; init; }
    public int Complexity { get; init; }
    public int ComplexityCapacity { get; init; }
    public int SourceCapacity { get; init; }
    public int SourceRechargePerRound { get; init; }
    public int SourcePeak { get; init; }
    public int LinkPeak { get; init; }
    public int BoardLoad { get; init; }
    public float RequiredProficiency { get; init; }
}

public sealed class FormationValidationResult
{
    public bool IsValid => Issues.Count == 0;
    public System.Collections.Generic.IReadOnlyList<FormationValidationIssue> Issues { get; init; }
        = System.Array.Empty<FormationValidationIssue>();
    public FormationCircuitMetrics Metrics { get; init; } = new();
}
