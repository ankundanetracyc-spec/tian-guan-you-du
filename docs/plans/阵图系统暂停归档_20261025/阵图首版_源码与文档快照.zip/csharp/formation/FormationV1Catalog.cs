using Godot;
using System.Collections.Generic;

/// <summary>首版可编辑阵图与其三个固定元件的唯一目录入口。</summary>
public static class FormationV1Catalog
{
    public const string CircuitId = "yunxi_third_spell_ward";
    public const string InputNodeId = "spell_input";
    public const string CounterNodeId = "third_spell_counter";
    public const string ActuatorNodeId = "ward_actuator";

    internal const string InputManualId = "manual_small_circulation_input";
    internal const string OutputManualId = "manual_guard_output";
    private const string TemplatePath = "res://resources/formations/云息周天护持阵.tres";
    private const string InputManualPath = "res://resources/formations/小周天聚灵阵录.tres";
    private const string OutputManualPath = "res://resources/formations/护元阵录.tres";

    // ResourceLoader wrappers must remain strongly reachable while the editor enumerates
    // many candidate circuits. Repeated temporary wrappers triggered Mono GCHandle errors.
    private static readonly object ResourceGate = new();
    private static FormationCircuitData? _template;
    private static Dictionary<string, FormationNodeData>? _templateNodes;
    private static FormationManualData? _inputManual;
    private static FormationManualData? _outputManual;

    public static FormationCircuitData CreateDefaultDraft() =>
        FormationCircuitService.CloneForEditing(LoadTemplate());

    public static FormationNodeData CreateNode(string nodeId)
    {
        if (!IsKnownNodeId(nodeId))
            throw new System.ArgumentOutOfRangeException(nameof(nodeId), nodeId, "首版目录不包含此元件");
        return FormationCircuitService.CloneNodeForEditing(GetTemplateNode(nodeId));
    }

    public static float RequiredProficiency(string nodeId) => nodeId switch
    {
        InputNodeId => 5.0f,
        CounterNodeId => 30.0f,
        ActuatorNodeId => 5.0f,
        _ => throw new System.ArgumentOutOfRangeException(nameof(nodeId), nodeId, "首版目录不包含此元件")
    };

    internal static bool IsKnownNodeId(string nodeId) =>
        nodeId is InputNodeId or CounterNodeId or ActuatorNodeId;

    internal static FormationCircuitData LoadTemplate()
    {
        if (_template is not null && GodotObject.IsInstanceValid(_template)) return _template;
        lock (ResourceGate)
        {
            if (_template is null || !GodotObject.IsInstanceValid(_template))
            {
                var template = LoadRequired<FormationCircuitData>(TemplatePath);
                var nodes = new Dictionary<string, FormationNodeData>(System.StringComparer.Ordinal);
                foreach (var node in template.nodes)
                    if (node is not null) nodes.TryAdd(node.node_id.ToString(), node);
                _template = template;
                _templateNodes = nodes;
            }
            return _template!;
        }
    }

    /// <summary>内部只读模板节点，禁止调用方修改；对外创建仍经深复制。</summary>
    internal static FormationNodeData GetTemplateNode(string nodeId)
    {
        LoadTemplate();
        if (_templateNodes is not null && _templateNodes.TryGetValue(nodeId, out var node)
            && GodotObject.IsInstanceValid(node))
            return node;
        throw new System.ArgumentOutOfRangeException(nameof(nodeId), nodeId, "首版模板没有此元件");
    }

    internal static FormationManualData LoadInputManual() =>
        LoadManual(ref _inputManual, InputManualPath);

    internal static FormationManualData LoadOutputManual() =>
        LoadManual(ref _outputManual, OutputManualPath);

    private static FormationManualData LoadManual(ref FormationManualData? cache, string path)
    {
        if (cache is not null && GodotObject.IsInstanceValid(cache)) return cache;
        lock (ResourceGate)
        {
            if (cache is null || !GodotObject.IsInstanceValid(cache)) cache = LoadRequired<FormationManualData>(path);
            return cache;
        }
    }

    private static T LoadRequired<T>(string path) where T : Resource =>
        ResourceLoader.Load<T>(path)
        ?? throw new System.InvalidOperationException($"无法读取阵法目录资源：{path}");
}
