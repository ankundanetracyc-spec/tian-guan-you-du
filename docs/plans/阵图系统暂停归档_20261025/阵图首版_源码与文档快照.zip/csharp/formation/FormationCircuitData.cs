using Godot;
using Godot.Collections;

/// <summary>
/// 可保存的个人战斗阵图。它只描述接口、元件和脉纹；阵源余量、计数等运行状态由 FormationCircuitRuntime 持有。
/// </summary>
public partial class FormationCircuitData : Resource
{
    [Export] public StringName circuit_id = new();
    [Export] public string circuit_name = "未命名阵图";
    [Export(PropertyHint.MultilineText)] public string description = "";
    [Export(PropertyHint.Range, "0,999,1")] public float required_formation_proficiency;
    [Export] public FormationHardwareData? hardware;
    /// <summary>此阵图实际引用的阵法录；载入战斗时必须已由角色解锁。</summary>
    [Export] public Array<string> required_manual_ids = [];
    [Export] public Array<FormationNodeData> nodes = [];
    [Export] public Array<FormationWireData> pulse_wires = [];

    public Array<string> validate_circuit()
    {
        var errors = new Array<string>();
        foreach (var issue in FormationCircuitService.Validate(
                     this,
                     float.MaxValue,
                     FormationCircuitService.RequiredManualIdsFor(this)).Issues)
            errors.Add(issue.Message);
        return errors;
    }

    public int complexity_cost() => nodes.Sum(node => node is null ? 0 : node.complexity_cost());
}
