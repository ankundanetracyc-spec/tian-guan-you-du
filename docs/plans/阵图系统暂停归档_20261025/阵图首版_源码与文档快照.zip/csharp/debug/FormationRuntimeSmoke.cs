using Godot;
using System.Reflection;
using GArray = Godot.Collections.Array;

/// <summary>以即时队列真实结算施术和应对，并验证阵源供能门槛及战斗运行态隔离。</summary>
public partial class FormationRuntimeSmoke : Node
{
    private const BindingFlags Private = BindingFlags.Instance | BindingFlags.NonPublic;
    private const string CircuitPath = "res://resources/formations/云息周天护持阵.tres";
    private const string SpellPath = "res://resources/activeskills/灵击.tres";
    private const string ResponsePath = "res://resources/activeskills/架招.tres";
    private const string AttackPath = "res://resources/activeskills/拳脚.tres";
    private int _checks;

    private void Check(bool condition, string label)
    {
        if (!condition) throw new InvalidOperationException(label);
        _checks++;
    }

    private static FormationCircuitData FreshCircuit()
        => GD.Load<FormationCircuitData>(CircuitPath)?.Duplicate(true) as FormationCircuitData
           ?? throw new InvalidOperationException("示范阵图无法深复制。");

    private static Creature MakeRuntimeOwner(string name = "阵法运行态验收")
        => new() { entity_name = name, entity_data = new HumanData { current_health = 1000, max_health = 1000 } };

    private static System.Collections.Generic.Dictionary<string, int> Counters(FormationCircuitRuntime runtime)
        => (System.Collections.Generic.Dictionary<string, int>)typeof(FormationCircuitRuntime)
            .GetField("_counters", Private)!.GetValue(runtime)!;

    private static System.Collections.Generic.HashSet<string> Fired(FormationCircuitRuntime runtime)
        => (System.Collections.Generic.HashSet<string>)typeof(FormationCircuitRuntime)
            .GetField("_firedThisTurn", Private)!.GetValue(runtime)!;

    private static Godot.Collections.Dictionary Snapshot(FormationCircuitRuntime runtime) => runtime.snapshot();

    public override void _Ready() => CallDeferred(nameof(Run));

    private async void Run()
    {
        try
        {
            VerifyRuntimeRoundsAndEnergyGate();
            VerifyIndependentPeakGates();
            await VerifyQueueEventsAndTargets();
            await VerifyRealQueuedResponse();
            VerifySetupUsesValidatedQualifications();
            await CleanupBattleScene();
            GD.Print($"FORMATION_RUNTIME_SMOKE: {_checks} checks passed");
            GetTree().Quit();
        }
        catch (Exception error)
        {
            GD.PushError("FORMATION_RUNTIME_SMOKE_FAILED: " + error);
            GetTree().Quit(1);
        }
    }

    private async Task CleanupBattleScene()
    {
        foreach (var child in GetParent().GetChildren().OfType<Node>().Where(child => child != this).ToArray())
            if (GodotObject.IsInstanceValid(child)) child.QueueFree();
        await ToSignal(GetTree(), SceneTree.SignalName.ProcessFrame);
    }

    private void VerifyRuntimeRoundsAndEnergyGate()
    {
        var manager = new BattleManager();
        var owner = MakeRuntimeOwner();
        manager.all_units.Add(owner);
        manager.battle_running = true;
        var circuitData = FreshCircuit();
        var runtime = new FormationCircuitRuntime(circuitData, owner, manager);

        runtime.begin_owner_turn();
        runtime.emit("spell_played", "spell");
        runtime.emit("spell_played", "spell");
        Check(Counters(runtime).GetValueOrDefault("third_spell_counter") == 2 && owner.shield == 0,
            "两次施术只积累三候计数，不提前启动护持");

        runtime.begin_owner_turn();
        runtime.emit("spell_played", "spell");
        var counterAfterCrossRound = Counters(runtime).GetValueOrDefault("third_spell_counter");
        Check(counterAfterCrossRound == 0 && owner.shield == 2,
            $"三候计数跨完整轮保留，跨轮第2+1次施术立即成功护持（计数={counterAfterCrossRound}，护持={owner.shield}，阵能={Snapshot(runtime)["source_energy"]}，启动={string.Join(',', Fired(runtime))}）");
        var afterFirstStart = Snapshot(runtime)["source_energy"].AsInt32();
        runtime.emit("spell_played", "spell");
        runtime.emit("spell_played", "spell");
        runtime.emit("spell_played", "spell");
        Check(owner.shield == 2 && Snapshot(runtime)["source_energy"].AsInt32() == afterFirstStart,
            "同轮第二个控制信号不重复启动或扣阵能");

        runtime.begin_owner_turn();
        runtime.emit("spell_played", "spell");
        runtime.emit("spell_played", "spell");
        runtime.emit("spell_played", "spell");
        Check(owner.shield == 4 && Snapshot(runtime)["source_energy"].AsInt32() == afterFirstStart,
            "下一完整轮补能一次并恢复一次成功启动资格");

        var lowEnergyData = FreshCircuit();
        lowEnergyData.hardware!.source_capacity = 1; // 蕴灵词缀使有效容量正好为2。
        lowEnergyData.hardware.source_recharge_per_turn = 0; // 聚灵词缀使每轮回复正好为1。
        var lowOwner = MakeRuntimeOwner("阵能余量负例");
        manager.all_units.Add(lowOwner);
        var lowRuntime = new FormationCircuitRuntime(lowEnergyData, lowOwner, manager);
        lowRuntime.emit("spell_played", "spell");
        lowRuntime.emit("spell_played", "spell");
        lowRuntime.emit("spell_played", "spell");
        Check(lowOwner.shield == 2 && Snapshot(lowRuntime)["source_energy"].AsInt32() == 0,
            "阵源恰有2阵能时可正常支付一次");
        lowRuntime.begin_owner_turn();
        lowRuntime.emit("spell_played", "spell");
        lowRuntime.emit("spell_played", "spell");
        lowRuntime.emit("spell_played", "spell");
        Check(lowOwner.shield == 2 && Snapshot(lowRuntime)["source_energy"].AsInt32() == 1
            && !Fired(lowRuntime).Contains("ward_actuator"),
            "仅有1阵能时信号丢弃，不扣能、不占成功名额");
        Check(Counters(lowRuntime).GetValueOrDefault("third_spell_counter") == 0,
            "阵能不足时计数归零，不排队延迟补发");
        lowRuntime.begin_owner_turn();
        lowRuntime.emit("spell_played", "spell");
        lowRuntime.emit("spell_played", "spell");
        Check(lowOwner.shield == 2 && Counters(lowRuntime).GetValueOrDefault("third_spell_counter") == 2,
            "失败信号不在后续轮自动补发，必须重新积累三次事件");
        lowRuntime.emit("spell_played", "spell");
        Check(lowOwner.shield == 4 && Snapshot(lowRuntime)["source_energy"].AsInt32() == 0,
            "重新积累三次且补足阵能后才再次启动");

        var newBattleRuntime = new FormationCircuitRuntime(circuitData, owner, manager);
        newBattleRuntime.emit("spell_played", "spell");
        Check(Counters(newBattleRuntime).GetValueOrDefault("third_spell_counter") == 1 && owner.shield == 4,
            "新战斗运行态从零计数且不沿用旧运行态");
        Check(circuitData.nodes.Single(node => node.node_id == "third_spell_counter").interval == 3
            && circuitData.nodes.Single(node => node.node_id == "ward_actuator").energy_cost == 2,
            "运行计数和阵能不写回已装配的阵图快照");

        owner.Free();
        lowOwner.Free();
        manager.Free();
    }

    private void VerifyIndependentPeakGates()
    {
        VerifyPeakGate("阵源峰值", hardware => hardware.source_peak_output = 1, hardware => hardware.source_peak_output = 2);
        VerifyPeakGate("灵络峰值", hardware => hardware.spirit_link_peak_output = 0, hardware => hardware.spirit_link_peak_output = 2);
        VerifyPeakGate("阵盘负荷", hardware => hardware.board_peak_load = 0, hardware => hardware.board_peak_load = 2);
    }

    private void VerifyPeakGate(string label, Action<FormationHardwareData> lower, Action<FormationHardwareData> restore)
    {
        var manager = new BattleManager();
        var owner = MakeRuntimeOwner(label);
        manager.all_units.Add(owner);
        manager.battle_running = true;
        var data = FreshCircuit();
        var runtime = new FormationCircuitRuntime(data, owner, manager);
        var actuator = data.nodes.Single(node => node.node_id == "ward_actuator");
        var sourceBefore = Snapshot(runtime)["source_energy"].AsInt32();
        lower(data.hardware!);
        typeof(FormationCircuitRuntime).GetMethod("try_activate", Private)!.Invoke(runtime, [actuator]);
        Check(owner.shield == 0 && Snapshot(runtime)["source_energy"].AsInt32() == sourceBefore
            && !Fired(runtime).Contains("ward_actuator"), $"{label}不足时不产生效果、不扣阵能、不占成功名额");
        restore(data.hardware!);
        typeof(FormationCircuitRuntime).GetMethod("try_activate", Private)!.Invoke(runtime, [actuator]);
        Check(owner.shield == 2 && Snapshot(runtime)["source_energy"].AsInt32() == sourceBefore - 2,
            $"{label}恢复至需求值后同轮可正常启动");
        owner.Free();
        manager.Free();
    }

    private async Task VerifyQueueEventsAndTargets()
    {
        var manager = GetParent().GetNode<BattleManager>("BattleMgr");
        manager.action_slots_per_segment = 5;
        var characterScene = PackCharacter();
        var circuitData = FreshCircuit();
        var playerData = MakeBattleData("队列施术者", 1, [SpellPath], circuitData, 100000f, 3);
        var enemyData = MakeBattleData("队列目标", 2, [], null, 100000f, 0);
        manager.setup_team_battle(
            new GArray { characterScene }, new GArray { characterScene },
            new GArray { playerData }, new GArray { enemyData });
        await WaitUntil(() => manager.can_player_plan(), "玩家进入首轮规划");
        var player = manager.get_main_player_unit()!;
        var enemy = manager.enemy_units[0];
        var spell = Loadout(manager, player).Single(skill => skill.skill_name == "灵击");
        spell.mana_cost = 1; // 只在本 smoke 的技能快照中设置费用，项目资源仍为原配置0。
        spell.uses_per_round = 2;
        player.Set("current_stamina", 6);
        var runtime = Runtimes(manager, player).Single();

        manager.on_skill_selected(spell, 0);
        Check(manager.get_filled_action_slot_count(player) == 1 && manager.cancel_player_action(0),
            "规划中取消真实队列技能成功");
        Check(manager.get_filled_action_slot_count(player) == 0 && player.Get("current_mana").AsInt32() == 3
            && Counter(runtime) == 0 && manager.get_skill_cooldown_rounds(player, spell) == 0,
            "取消不扣法力、不触发阵法、不消耗次数或冷却");

        var noTarget = new BattleQueuedSkill(spell, enemy);
        var enemyHealth = enemy.Get("current_health").AsInt32();
        enemy.Set("current_health", 0);
        manager.all_units.Remove(enemy);
        bool noTargetCanResolve;
        try
        {
            noTargetCanResolve = (bool)typeof(BattleManager).GetMethod("CanResolveSegmentAction", Private)!
                .Invoke(manager, [player, noTarget, false])!;
        }
        finally
        {
            manager.all_units.Add(enemy);
            enemy.Set("current_health", enemyHealth);
        }
        Check(!noTargetCanResolve && player.Get("current_stamina").AsInt32() == 6
            && player.Get("current_mana").AsInt32() == 3 && Counter(runtime) == 0,
            $"没有合法敌方目标时在费用检查前拒绝技能，不扣费或触发阵法（可结算={noTargetCanResolve}，精力={player.Get("current_stamina")}，法力={player.Get("current_mana")}，计数={Counter(runtime)}）");
        Check(manager.is_skill_ready(player, spell) && manager.get_skill_cooldown_rounds(player, spell) == 0,
            "无合法目标不占每轮次数或冷却");

        manager.on_skill_selected(spell, 0);
        manager.on_skill_selected(spell, 0);
        Check(manager.get_filled_action_slot_count(player) == 2, "两次技能进入玩家真实行动队列");
        manager.confirm_player_queue();
        await WaitUntil(() => Counter(runtime) == 1 && manager.get_current_action_slot(player) >= 1,
            "第一个真实队列施术事件");
        Check(player.Get("current_mana").AsInt32() == 2 && player.Get("shield").AsInt32() == 0,
            "首个真实技能实际扣1法力且仅累计一次施术信号");
        await WaitUntil(() => Counter(runtime) == 2 && manager.get_current_action_slot(player) >= 2,
            "第二个真实队列施术事件");
        Check(player.Get("current_mana").AsInt32() == 1 && player.Get("shield").AsInt32() == 0,
            "第二个真实技能实际扣1法力，三候未提前触发");

        var firstRound = SegmentNumber(manager);
        await WaitUntil(() => SegmentNumber(manager) > firstRound && manager.can_player_plan(), "进入下一完整轮规划");
        Check(Counter(runtime) == 2 && player.Get("shield").AsInt32() == 0,
            "进入新轮时阵图运行计数仍跨轮保留");
        player.Set("current_stamina", 6);
        manager.on_skill_selected(spell, 0);
        manager.confirm_player_queue();
        await WaitUntil(() => Counter(runtime) == 0 && manager.get_current_action_slot(player) >= 1,
            "跨轮第3次真实队列施术事件");
        Check(player.Get("current_mana").AsInt32() == 2 && player.Get("shield").AsInt32() == 2,
            "跨轮2+1后按实际法力支付启动护持并显示数值状态");

    }

    private async Task VerifyRealQueuedResponse()
    {
        var manager = GetParent().GetNode<BattleManager>("BattleMgr");
        foreach (var oldUnit in manager.all_units.OfType<Node>().ToArray()) oldUnit.QueueFree();
        await ToSignal(GetTree(), SceneTree.SignalName.ProcessFrame);
        var characterScene = PackCharacter();
        var circuitData = FreshCircuit();
        var playerData = MakeBattleData("真实应对者", 1, [ResponsePath], circuitData, 20f, 3);
        var enemyData = MakeBattleData("真实来袭者", 2, [AttackPath], null, 1000000f, 0);
        manager.set_spectator_battle(false);
        manager.setup_team_battle(
            new GArray { characterScene }, new GArray { characterScene },
            new GArray { playerData }, new GArray { enemyData });
        await WaitUntil(() => manager.can_player_plan(), "应对战斗进入规划");
        var player = manager.get_main_player_unit()!;
        var response = Loadout(manager, player).Single(skill => skill.skill_name == "架招");
        response.mana_cost = 1; // 只设置验收快照费用；生产应对资源保持不变。
        response.cooldown_rounds = 1;
        response.uses_per_round = 1;
        player.Set("current_stamina", 6);
        var runtime = Runtimes(manager, player).Single();
        Check(Counter(runtime) == 0, "新战斗建立独立且清零的阵图运行态");

        manager.on_skill_selected(response, 0);
        manager.confirm_player_queue();
        manager.set_spectator_battle(true); // 保留真实队列和受击入口，跳过仅供视觉检查的冻结特写。
        await WaitUntil(() => Counter(runtime) == 1 && manager.get_current_action_slot(player) >= 1,
            "真实来袭命中队首并触发实际付费应对");
        Check(player.Get("current_mana").AsInt32() == 2,
            "真实应对按支付前后法力差扣1法力并仅发一次施术事件");
        Check(player.Get("shield").AsInt32() == 0 && manager.get_skill_cooldown_rounds(player, response) == 2
            && manager.get_skill_round_cooldown_text(player, response).Contains("第3回合"),
            $"真实应对走自身结算并启动一次原技能冷却，未提前触发三候护持（护持={player.Get("shield")}，冷却={manager.get_skill_cooldown_rounds(player, response)}，轮次={SegmentNumber(manager)}，计数={Counter(runtime)}）");

    }

    private void VerifySetupUsesValidatedQualifications()
    {
        var manager = GetParent().GetNode<BattleManager>("BattleMgr");
        var characterScene = PackCharacter();

        var admittedCircuit = FreshCircuit();
        admittedCircuit.required_formation_proficiency = 0;
        admittedCircuit.required_manual_ids.Clear();
        var admitted = MakeBattleData("三候造诣30", 1, [], admittedCircuit, 100f, 0);

        var lowCircuit = FreshCircuit();
        lowCircuit.required_formation_proficiency = 0;
        lowCircuit.required_manual_ids.Clear();
        var low = MakeBattleData("三候造诣29", 1, [], lowCircuit, 100f, 0);
        low.formation_proficiency = 29;

        var missingManualCircuit = FreshCircuit();
        missingManualCircuit.required_formation_proficiency = 0;
        missingManualCircuit.required_manual_ids.Clear();
        var missingManual = MakeBattleData("缺护元阵录", 1, [], missingManualCircuit, 100f, 0);
        missingManual.formation_manual_ids = ["manual_small_circulation_input"];

        var enemy = MakeBattleData("资格校验敌方", 2, [], null, 0f, 0);
        manager.set_spectator_battle(true);
        manager.setup_team_battle(
            new GArray { characterScene, characterScene, characterScene }, new GArray { characterScene },
            new GArray { admitted, low, missingManual }, new GArray { enemy });
        Check(manager.player_units.Count == 3 && manager.enemy_units.Count == 1,
            "资格校验案例通过真实 setup_team_battle 生成双方参战单位");

        var admittedUnit = manager.player_units[0];
        var lowUnit = manager.player_units[1];
        var missingManualUnit = manager.player_units[2];
        Check(Runtimes(manager, admittedUnit).Count == 1,
            "正式组队对造诣30且持两本阵录者载入阵图，即使存档声明门槛被伪造为0");
        Check(Runtimes(manager, lowUnit).Count == 0,
            "正式组队按实际造诣拒绝29者，不能被存档声明门槛0绕过");
        Check(Runtimes(manager, missingManualUnit).Count == 0,
            "正式组队按实际阵录拒绝缺少护元阵录者，不能被清空的声明绕过");
    }

    private static BattleEntityData MakeBattleData(string name, int faction, Godot.Collections.Array<string> slots,
        FormationCircuitData? circuit, float initiative, int maxMana)
    {
        var data = new BattleEntityData
        {
            uid = "formation-smoke-" + Guid.NewGuid().ToString("N"),
            entity_name = name,
            entity_type = (int)WorldEntity.EntityType.CHARACTER,
            faction = faction,
            cultivation_realm = "云息三层",
            physique = 16,
            intelligence = 16,
            agility = 16,
            soul = 16,
            max_health = 10000,
            current_health = 10000,
            max_stamina = 6,
            current_stamina = 0,
            max_mana = maxMana,
            current_mana = 0,
            initiative_speed = initiative,
            combat_skill_slot_paths = slots,
            combat_skill_slots_configured = true,
            formation_proficiency = 30,
            formation_manual_ids = ["manual_small_circulation_input", "manual_guard_output"],
            formation_circuits = []
        };
        if (circuit is not null) data.formation_circuits.Add(circuit);
        return data;
    }

    private static PackedScene PackCharacter()
    {
        var prototype = new Character();
        var packed = new PackedScene();
        if (packed.Pack(prototype) != Error.Ok) throw new InvalidOperationException("无法准备隔离战斗角色场景。");
        prototype.Free();
        return packed;
    }

    private static Godot.Collections.Array<ActiveSkillData> Loadout(BattleManager manager, GodotObject unit)
        => ((System.Collections.Generic.Dictionary<GodotObject, Godot.Collections.Array<ActiveSkillData>>)
            typeof(BattleManager).GetField("_combatSkills", Private)!.GetValue(manager)!)[unit];

    private static List<FormationCircuitRuntime> Runtimes(BattleManager manager, GodotObject unit)
        => ((System.Collections.Generic.Dictionary<GodotObject, List<FormationCircuitRuntime>>)
            typeof(BattleManager).GetField("_formationCircuits", Private)!.GetValue(manager)!).GetValueOrDefault(unit, []);

    private static int Counter(FormationCircuitRuntime runtime)
        => Counters(runtime).GetValueOrDefault("third_spell_counter");

    private static int SegmentNumber(BattleManager manager)
        => (int)typeof(BattleManager).GetField("_segmentNumber", Private)!.GetValue(manager)!;

    private async Task WaitUntil(Func<bool> condition, string label, int maxFrames = 1800)
    {
        for (var frame = 0; frame < maxFrames; frame++)
        {
            if (condition()) return;
            await ToSignal(GetTree(), SceneTree.SignalName.ProcessFrame);
        }
        throw new TimeoutException("等待超时：" + label);
    }
}
