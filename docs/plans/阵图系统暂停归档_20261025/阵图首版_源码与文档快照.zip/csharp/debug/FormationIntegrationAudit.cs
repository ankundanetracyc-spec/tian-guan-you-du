using Godot;

/// <summary>统筹独立验收：穷举首版三节点有向连线，防止捷径绕过候枢或草稿污染装配。</summary>
public partial class FormationIntegrationAudit : Node
{
    private int _checks;
    private void Check(bool value, string message)
    {
        if (!value) throw new InvalidOperationException(message);
        _checks++;
    }

    public override void _Ready()
    {
        try
        {
            var template = FormationV1Catalog.CreateDefaultDraft();
            var manuals = template.required_manual_ids.ToArray();
            string[] ids = ["spell_input", "third_spell_counter", "ward_actuator"];
            var edges = (from a in ids from b in ids where a != b select (a, b)).ToArray();
            var validGraphs = 0;
            for (var mask = 0; mask < (1 << edges.Length); mask++)
            {
                var draft = FormationCircuitService.CloneForEditing(template);
                draft.pulse_wires.Clear();
                for (var bit = 0; bit < edges.Length; bit++)
                    if ((mask & (1 << bit)) != 0)
                        draft.pulse_wires.Add(new FormationWireData { from_node_id = edges[bit].a, to_node_id = edges[bit].b });
                var expected = draft.pulse_wires.Count == 2 &&
                    draft.pulse_wires.Any(w => w.from_node_id == "spell_input" && w.to_node_id == "third_spell_counter") &&
                    draft.pulse_wires.Any(w => w.from_node_id == "third_spell_counter" && w.to_node_id == "ward_actuator");
                var result = FormationCircuitService.Validate(draft, 30, manuals);
                Check(result.IsValid == expected, $"三节点图 mask={mask} 预期合法={expected}，实际={result.IsValid}：{string.Join("；", result.Issues.Select(i => i.Message))}");
                if (result.IsValid) validGraphs++;
            }
            Check(validGraphs == 1, "三节点只允许感应→三候→护持这一个单链");

            var direct = FormationCircuitService.CloneForEditing(template);
            direct.nodes = new(direct.nodes.Where(n => n.node_id != "third_spell_counter"));
            direct.pulse_wires = [new FormationWireData { from_node_id = "spell_input", to_node_id = "ward_actuator" }];
            Check(FormationCircuitService.Validate(direct, 5, manuals).IsValid, "两节点直连按实际元件造诣5可用");
            Check(!FormationCircuitService.Validate(template, 29, manuals).IsValid, "三候造诣29被拒绝");
            foreach (var missing in manuals)
            {
                var spoof = FormationCircuitService.CloneForEditing(template);
                spoof.required_manual_ids.Clear();
                spoof.required_formation_proficiency = 0;
                var result = FormationCircuitService.Validate(spoof, 30, manuals.Where(id => id != missing));
                Check(!result.IsValid && result.Issues.Any(i => i.Code == "missing_manual"), "删除声明不能绕过实际接口阵录：" + missing);
            }

            var owner = new HumanData { formation_proficiency = 30, formation_manual_ids = new(manuals) };
            Check(FormationCircuitService.TryApply(owner, template, out _), "合法示范可装配");
            var equipped = owner.formation_circuits.Single();
            var draftEdit = FormationCircuitService.CloneForEditing(equipped);
            draftEdit.nodes[0].editor_position = new Vector2(123, 456);
            Check(equipped.nodes[0].editor_position != draftEdit.nodes[0].editor_position, "草稿位置与装配不共享");
            draftEdit.nodes[0].input_event = "forged_event";
            Check(!FormationCircuitService.TryApply(owner, draftEdit, out _), "篡改输入事件被拒绝");
            Check(ReferenceEquals(equipped, owner.formation_circuits.Single()) && equipped.nodes[0].input_event == "spell_played", "失败保存保持原装配及内容");
            Check(template.nodes[0].input_event == "spell_played", "草稿不污染示范模板");
            GD.Print($"FORMATION_INTEGRATION_AUDIT: {_checks} checks passed (64 directed graphs independently enumerated)");
            GetTree().Quit();
        }
        catch (Exception error)
        {
            GD.PushError("FORMATION_INTEGRATION_AUDIT_FAILED: " + error);
            GetTree().Quit(1);
        }
    }
}
