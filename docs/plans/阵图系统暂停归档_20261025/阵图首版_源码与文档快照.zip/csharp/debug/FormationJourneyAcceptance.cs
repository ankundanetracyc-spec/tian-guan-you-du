using Godot;
using System.Diagnostics;
using System.Globalization;
using System.Reflection;
using System.Threading.Tasks;
using GArray = Godot.Collections.Array;
using GDictionary = Godot.Collections.Dictionary;

/// <summary>
/// 独立双进程验收：正式百工按钮/画布输入/Ctrl+S→正式战场→结算返回→退出→标题页载入。
/// 现行正式技能法力费均为0；付费正例仅使用不写盘的内存夹具，不改正式技能或发放成长。
/// </summary>
public partial class FormationJourneyAcceptance : Node
{
    private const string SaveName = "阵图首版独立流程验收";
    private const BindingFlags Private = BindingFlags.Instance | BindingFlags.NonPublic;
    private string _isolatedUserDirectory = "";
    private int _checks;

    private void Check(bool ok, string label)
    {
        if (!ok) throw new InvalidOperationException(label);
        _checks++;
    }
    private static string Arg(string prefix) => OS.GetCmdlineUserArgs().FirstOrDefault(s => s.StartsWith(prefix, StringComparison.Ordinal))?[prefix.Length..] ?? "";
    private static string Full(string path) => System.IO.Path.TrimEndingDirectorySeparator(System.IO.Path.GetFullPath(path));
    private static T Field<T>(object owner, string name) => (T)(owner.GetType().GetField(name, Private)?.GetValue(owner) ?? throw new InvalidOperationException("缺少字段：" + name));
    private static IEnumerable<T> Descendants<T>(Node node) where T : Node
    {
        foreach (var child in node.GetChildren())
        {
            if (child is T match) yield return match;
            foreach (var descendant in Descendants<T>(child)) yield return descendant;
        }
    }
    private async Task Frames(int count = 2)
    {
        for (var i = 0; i < count; i++) await ToSignal(GetTree(), SceneTree.SignalName.ProcessFrame);
    }
    private void Push(InputEvent input)
    {
        if (input is InputEventFromWindow fromWindow) fromWindow.WindowId = GetWindow().GetWindowId();
        Input.ParseInputEvent(input);
        Input.FlushBufferedEvents();
    }
    private async Task Until(Func<bool> condition, string label, int seconds = 75)
    {
        var timer = Stopwatch.StartNew();
        while (!condition())
        {
            if (timer.Elapsed.TotalSeconds > seconds) throw new TimeoutException(label);
            await Frames(1);
        }
    }
    private void VerifyIsolation()
    {
        var expected = Arg("--expected-appdata=");
        Check(expected.Length > 0 && Full(OS.GetEnvironment("APPDATA")) == Full(expected), "APPDATA未明确隔离，拒绝验收存档");
        var custom = ProjectSettings.GetSetting("application/config/custom_user_dir_name").AsString();
        _isolatedUserDirectory = Full(OS.GetUserDataDir());
        Check(custom.Length > 0 && string.Equals(_isolatedUserDirectory, Full(System.IO.Path.Combine(expected, custom)), StringComparison.OrdinalIgnoreCase), "user://未解析到本次隔离目录");
        var saves = Full(ProjectSettings.GlobalizePath("user://game_saves"));
        Check(saves.StartsWith(_isolatedUserDirectory + System.IO.Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase), "存档目录越界");
        GD.Print("FORMATION_JOURNEY_ISOLATED: " + _isolatedUserDirectory);
    }

    public override void _Ready()
    {
        ProcessMode = ProcessModeEnum.Always;
        CallDeferred(nameof(Run));
    }
    private async void Run()
    {
        try
        {
            VerifyIsolation();
            // 保留此验收节点跨场景运行，不把它打包进任何正式场景或存档。
            GetTree().CurrentScene = null;
            GetWindow().Mode = Window.ModeEnum.Windowed;
            GetWindow().Size = new Vector2I(1920, 1080);
            GetWindow().ContentScaleSize = new Vector2I(1920, 1080);
            if (Arg("--phase=") == "write") await WritePhase();
            else if (Arg("--phase=") == "read") await ReadPhase();
            else throw new InvalidOperationException("需要 --phase=write 或 --phase=read");
            GD.Print($"FORMATION_JOURNEY_{Arg("--phase=").ToUpperInvariant()}: {_checks} checks passed");
            GetTree().Quit();
        }
        catch (Exception error)
        {
            GD.PushError("FORMATION_JOURNEY_FAILED: " + error);
            GetTree().Paused = false;
            GetTree().Quit(1);
        }
    }
    private async Task<MainScene> WaitMain()
    {
        await Until(() => GetTree().CurrentScene is MainScene { StartupComplete: true } && !SceneLoadingScreen.IsChangingScene, "正式主场景初始化超时");
        var main = (MainScene)GetTree().CurrentScene;
        Check(main.StartupError is null, "主场景初始化出错：" + main.StartupError);
        await Frames(3);
        return main;
    }
    private async Task<BaigongPanel> OpenBaigong(MainScene main)
    {
        var craft = Descendants<Button>(main).Single(button => button.Name == "BtnCraft");
        craft.EmitSignal(BaseButton.SignalName.Pressed);
        await Frames();
        var panel = Descendants<BaigongPanel>(main).Single();
        Check(panel.Visible, "正式百工按钮没有打开面板");
        return panel;
    }
    private static string Fingerprint(FormationCircuitData circuit)
    {
        var nodes = circuit.nodes.OrderBy(n => n.node_id.ToString()).Select(n => $"{n.node_id}:{n.has_editor_position}:{n.editor_position.X.ToString("R", CultureInfo.InvariantCulture)},{n.editor_position.Y.ToString("R", CultureInfo.InvariantCulture)}");
        var wires = circuit.pulse_wires.Select(w => $"{w.from_node_id}>{w.to_node_id}").OrderBy(s => s);
        return circuit.circuit_id + "|" + string.Join(";", nodes) + "|" + string.Join(";", wires);
    }
    private static FormationCircuitData Equipped(Character player) => ((HumanData)player.entity_data!).formation_circuits.Single(c => c.circuit_id.ToString() == FormationV1Catalog.CircuitId);

    private async Task DragHeader(GraphNode node)
    {
        var from = node.GetGlobalTransformWithCanvas() * new Vector2(60, 15);
        Push(new InputEventMouseMotion { Position = from, GlobalPosition = from });
        await Frames();
        Push(new InputEventMouseButton { Position = from, GlobalPosition = from, ButtonIndex = MouseButton.Left, Pressed = true });
        await Frames();
        for (var i = 1; i <= 8; i++)
        {
            var at = from + new Vector2(i * 5, i * 5);
            Push(new InputEventMouseMotion { Position = at, GlobalPosition = at, Relative = new Vector2(5, 5), ButtonMask = MouseButtonMask.Left });
            await Frames(1);
        }
        var to = from + new Vector2(40, 40);
        Push(new InputEventMouseButton { Position = to, GlobalPosition = to, ButtonIndex = MouseButton.Left, Pressed = false });
        await Frames();
    }
    private async Task WritePhase()
    {
        var saveManager = GetNode<GameSaveManager>("/root/GameSaveManager");
        Check(saveManager.get_save_slots().Count == 0, "写阶段必须使用新的空隔离目录");
        saveManager.begin_new_game(SaveName);
        Check(GetTree().ChangeSceneToFile("res://tscn/scene/MainScene.tscn") == Error.Ok, "无法打开正式主场景");
        var main = await WaitMain();
        var player = main.get_player_character()!;
        var human = (HumanData)player.entity_data!;
        // 仅此隔离验收人物提供既有两阵录与造诣；生产建档流程不发放。
        human.base_formation_proficiency = human.formation_proficiency = 30;
        human.formation_manual_ids = FormationV1Catalog.CreateDefaultDraft().required_manual_ids.Duplicate();
        Check(main.save_from_gameplay_menu(), "无法建立隔离正式存档");
        var panel = await OpenBaigong(main);
        var graph = Descendants<GraphEdit>(panel).Single();
        var input = graph.GetNode<GraphNode>("spell_input");
        var oldPosition = input.PositionOffset;
        await DragHeader(input);
        Check(input.PositionOffset != oldPosition, "真实视口拖动未改变元件位置");
        Push(new InputEventKey { Keycode = Key.Escape, PhysicalKeycode = Key.Escape, Pressed = true });
        await Frames();
        Push(new InputEventKey { Keycode = Key.Escape, PhysicalKeycode = Key.Escape, Pressed = false });
        Check(GetTree().Paused && panel.Visible, "编辑器Esc未保留全局暂停行为");
        Push(new InputEventKey { Keycode = Key.Escape, PhysicalKeycode = Key.Escape, Pressed = true });
        await Frames();
        Push(new InputEventKey { Keycode = Key.Escape, PhysicalKeycode = Key.Escape, Pressed = false });
        Check(!GetTree().Paused && panel.Visible, "解除暂停时错误离开编辑器");
        var changes = 0;
        var changedEvent = typeof(BaigongPanel).GetEvent("FormationChanged");
        Check(changedEvent is not null, "百工缺少公共配置变更通知");
        changedEvent!.AddEventHandler(panel, (Action)(() => changes++));
        Push(new InputEventKey { Keycode = Key.S, CtrlPressed = true, Pressed = true });
        await Frames(1);
        Push(new InputEventKey { Keycode = Key.S, CtrlPressed = true, Pressed = false });
        Check(changes == 1, "真实Ctrl+S未保存装配或通知次数不为1");
        Check(main.has_unsaved_progress, "阵图装配未进入主场景自动保存流程");
        var expected = Fingerprint(Equipped(player));
        Check(Equipped(player).nodes.Single(n => n.node_id == "spell_input").editor_position == input.PositionOffset, "草稿位置未写入装配");
        await Until(() => !main.has_unsaved_progress, "阵图修改未自动保存", 12);
        GD.Print("FORMATION_JOURNEY_STAGE: editor viewport drag / Ctrl+S / autosave passed");
        var backPoint = input.GetGlobalRect().GetCenter();
        Push(new InputEventMouseButton { Position = backPoint, GlobalPosition = backPoint, ButtonIndex = MouseButton.Right, Pressed = true });
        await Frames(1);
        Push(new InputEventMouseButton { Position = backPoint, GlobalPosition = backPoint, ButtonIndex = MouseButton.Right, Pressed = false });
        await Frames();
        Check(!panel.Visible, "保存后真实右键未经过全局返回关闭面板");

        var transition = GetNode<BattleTransitionManager>("/root/BattleTransitionManager");
        var heroData = player.get_snapshot_data();
        heroData.max_mana = heroData.current_mana = 6;
        heroData.initiative_speed = 10000;
        heroData.combat_skill_slots_configured = true;
        heroData.combat_skill_slot_paths = [];
        heroData.combat_passive_paths = [];
        heroData.main_gongfa_path = ""; heroData.sub_gongfa_paths = []; heroData.gongfa_paths = [];
        var foe = new BattleEntityData { uid = "formation-acceptance-foe", entity_name = "阵图验收陪练", faction = 2, current_health = 10000, max_health = 10000, max_stamina = 6, initiative_speed = 20, combat_skill_slots_configured = true };
        var avatar = GD.Load<PackedScene>("res://tscn/battle/BattleTestCharacter.tscn");
        transition.set_battle_return_context(new GDictionary { ["kind"] = "formation_acceptance", ["title"] = "阵图验收", ["allow_retreat"] = false });
        transition.start_team_battle([avatar], [avatar], new GArray { heroData }, new GArray { foe }, "res://tscn/scene/MainScene.tscn");
        await Until(() => Descendants<Button>(transition).Any(b => b.Text == "开始战斗" && !b.Disabled), "战前确认未出现");
        Descendants<Button>(transition).Single(b => b.Text == "开始战斗").EmitSignal(BaseButton.SignalName.Pressed);
        await Until(() => GetTree().CurrentScene is BattleScene && !transition.is_flow_transition_active() && GetTree().CurrentScene.GetNode<BattleManager>("BattleMgr").can_player_plan(), "正式战场未进入规划段");
        var manager = GetTree().CurrentScene.GetNode<BattleManager>("BattleMgr");
        var hero = manager.get_main_player_unit()!;
        Check(manager.get_formation_snapshot(hero).Count == 1, "正式战场没有载入已装配阵图");
        var fixture = (ActiveSkillData)GD.Load<ActiveSkillData>("res://resources/activeskills/聚息.tres").Duplicate(true);
        fixture.skill_name = "隔离付费施术夹具";
        fixture.energy_cost = 0; fixture.mana_cost = 1; fixture.keywords = []; fixture.special_effects = [];
        Field<System.Collections.Generic.Dictionary<GodotObject, Godot.Collections.Array<ActiveSkillData>>>(manager, "_combatSkills")[hero] = [fixture];
        for (var i = 0; i < 3; i++) manager.on_skill_selected(fixture, 0);
        Check(manager.get_filled_action_slot_count(hero) == 3, "付费夹具未通过正式排队入口加入三次");
        Check(hero.Get("shield").AsInt32() == 0, "规划阶段错误触发护持");
        manager.confirm_player_queue();
        await Until(() => hero.Get("current_mana").AsInt32() == 3 && hero.Get("shield").AsInt32() == 2
            && manager.get_current_action_slot(hero) >= 3, "三次真实付费队列行动未完整结算或未产生2点护持", 30);
        Check(manager.get_formation_snapshot(hero)[0]["source_energy"].AsInt32() == 3, "护持没有准确扣除2阵能");
        GD.Print("FORMATION_JOURNEY_STAGE: formal queue paid fixture x3 / ward +2 / energy -2 passed");
        // 结束隔离陪练，使用正式胜负检查、结算页及返回回调，不伪造战后存档。
        manager.enemy_units[0].Set("current_health", 0);
        await Until(() => Descendants<Button>(transition).Any(b => b.Text == "返回" && !b.Disabled) && !transition.is_flow_transition_active(), "战斗结算页未出现");
        Descendants<Button>(transition).Single(b => b.Text == "返回").EmitSignal(BaseButton.SignalName.Pressed);
        main = await WaitMain();
        player = main.get_player_character()!;
        Check(Fingerprint(Equipped(player)) == expected, "战后回传污染了阵图配置");
        Check(main.save_from_gameplay_menu(), "战后正式保存失败");
        System.IO.File.WriteAllText(System.IO.Path.Combine(_isolatedUserDirectory, "formation-expected.txt"), expected);
        var disk = ResourceLoader.Load<PersistentGameSave>($"user://game_saves/{saveManager.active_slot_id}.tres", cacheMode: ResourceLoader.CacheMode.Ignore)!;
        Check(disk.format_version == 8 && Fingerprint(disk.player_data!.formation_circuits.Single()) == expected, "正式v8保存没有保留阵图");
        GD.Print("FORMATION_JOURNEY_STAGE: native settlement / return / v8 save passed");
    }
    private async Task ReadPhase()
    {
        var saveManager = GetNode<GameSaveManager>("/root/GameSaveManager");
        Check(saveManager.get_save_slots().Count == 1 && saveManager.get_save_slots()[0]["name"].AsString() == SaveName, "读阶段必须只有本验收槽");
        Check(GetTree().ChangeSceneToFile("res://tscn/scene/StartMenu.tscn") == Error.Ok, "无法打开正式标题页");
        await Until(() => GetTree().CurrentScene is StartMenu, "标题页未出现");
        await Frames(3);
        var title = (StartMenu)GetTree().CurrentScene;
        title.GetNode<Button>("StartMenuMenu/LoadSave").EmitSignal(BaseButton.SignalName.Pressed);
        await Frames();
        Descendants<Button>(title).Single(b => b.Text.StartsWith(SaveName, StringComparison.Ordinal)).EmitSignal(BaseButton.SignalName.Pressed);
        var main = await WaitMain();
        var player = main.get_player_character()!;
        var expected = System.IO.File.ReadAllText(System.IO.Path.Combine(_isolatedUserDirectory, "formation-expected.txt"));
        Check(Fingerprint(Equipped(player)) == expected, "完全退出进程后标题载入的阵图连线或位置不一致");
        var human = (HumanData)player.entity_data!;
        Check(human.formation_manual_ids.Count == 2 && human.formation_proficiency >= 30, "角色既有阵录或造诣未随旅程恢复");
        var panel = await OpenBaigong(main);
        var graph = Descendants<GraphEdit>(panel).Single();
        foreach (var node in Equipped(player).nodes)
            Check(graph.GetNode<GraphNode>(node.node_id.ToString()).PositionOffset == node.editor_position, "读档后画布未恢复布局：" + node.node_id);
        Check(graph.GetConnectionList().Count == 2, "读档后画布未恢复两条脉纹");
        GD.Print("FORMATION_JOURNEY_STAGE: separate-process title load / equipped graph / editor layout passed");
    }
}
