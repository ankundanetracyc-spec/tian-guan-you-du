using Godot;
using Godot.Collections;
using System;
using System.Linq;

/// <summary>验证阵图目录、资格、结构、深复制和 v8 Resource 往返；不触碰正式存档槽。</summary>
public partial class FormationDataSmoke : Node
{
    private const string TemplatePath = "res://resources/formations/云息周天护持阵.tres";

    private static void Check(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
        GD.Print("FORMATION_DATA_CHECK_OK " + message);
    }

    private static bool HasCode(FormationValidationResult result, string code) =>
        result.Issues.Any(issue => issue.Code == code);

    private static Array<string> FullManuals()
    {
        var manuals = new Array<string>();
        manuals.Add("manual_small_circulation_input");
        manuals.Add("manual_guard_output");
        return manuals;
    }

    private static FormationWireData Wire(string from, string to) => new()
    {
        from_node_id = from,
        to_node_id = to
    };

    public override void _Ready()
    {
        try
        {
            RunChecks();
            GD.Print("FORMATION_DATA_SMOKE_OK");
            GetTree().Quit();
        }
        catch (Exception error)
        {
            GD.PushError(error.ToString());
            GetTree().Quit(1);
        }
    }

    private void RunChecks()
    {
        var template = ResourceLoader.Load<FormationCircuitData>(TemplatePath);
        Check(template is not null, "示范阵 Resource 可加载");
        Check(template!.required_formation_proficiency == 30.0f, "三候示范资源存档门槛为 30");
        Check(template.nodes.Count == 3 && template.pulse_wires.Count == 2, "示范阵恰有三类元件和两段串联脉纹");
        Check(template.nodes.All(node => node.has_editor_position), "示范阵节点均保存编辑器位置");

        var draft = FormationV1Catalog.CreateDefaultDraft();
        Check(!ReferenceEquals(template, draft) && !ReferenceEquals(template.hardware, draft.hardware), "默认草稿与模板/硬件 Resource 独立");
        Check(!ReferenceEquals(template.nodes, draft.nodes) && !ReferenceEquals(template.pulse_wires, draft.pulse_wires), "默认草稿数组独立");
        Check(!ReferenceEquals(template.nodes[0], draft.nodes[0])
              && !ReferenceEquals(template.nodes[0].accepted_source_tags, draft.nodes[0].accepted_source_tags), "默认草稿节点及节点数组独立");
        Check(!ReferenceEquals(template.pulse_wires[0], draft.pulse_wires[0]), "默认草稿脉纹 Resource 独立");

        draft.nodes[0].display_name = "草稿改名";
        draft.nodes[0].accepted_source_tags.Add("spoof");
        draft.hardware!.component_slots = 99;
        draft.pulse_wires[0].to_node_id = "spoof";
        Check(template.nodes[0].display_name == "术法感应枢"
              && !template.nodes[0].accepted_source_tags.Contains("spoof")
              && template.hardware!.component_slots == 4
              && template.pulse_wires[0].to_node_id.ToString() == FormationV1Catalog.CounterNodeId,
            "修改草稿不污染模板节点、硬件或脉纹");

        var firstNode = FormationV1Catalog.CreateNode(FormationV1Catalog.InputNodeId);
        var secondNode = FormationV1Catalog.CreateNode(FormationV1Catalog.InputNodeId);
        firstNode.accepted_source_tags.Add("local-only");
        Check(!ReferenceEquals(firstNode, secondNode)
              && !secondNode.accepted_source_tags.Contains("local-only"), "目录重复创建同一元件仍返回独立 Resource");

        var fullDraft = FormationV1Catalog.CreateDefaultDraft();
        fullDraft.required_formation_proficiency = 5.0f;
        fullDraft.required_manual_ids.Clear();
        var fullAt30 = FormationCircuitService.Validate(fullDraft, 30.0f, FullManuals());
        Check(fullAt30.IsValid, "三候链路在阵录齐全且造诣 30 时通过");
        Check(fullAt30.Metrics.UsedSlots == 4 && fullAt30.Metrics.SlotCapacity == 4
              && fullAt30.Metrics.Complexity == 4 && fullAt30.Metrics.ComplexityCapacity == 4,
            "三候链路格位和复杂度实测为 4/4");
        Check(fullAt30.Metrics.RequiredProficiency == 30.0f, "门槛从实际三候元件推导而非读取伪造声明字段");
        Check(fullAt30.Metrics.SourceCapacity == 5 && fullAt30.Metrics.SourceRechargePerRound == 2
              && fullAt30.Metrics.SourcePeak == 2 && fullAt30.Metrics.LinkPeak == 3
              && fullAt30.Metrics.BoardLoad == 3,
            "容量、补能、阵源峰值、灵络峰值和阵盘负荷读取有效硬件值");

        var stressManuals = FullManuals();
        for (var i = 0; i < 64; i++)
        {
            var candidate = FormationV1Catalog.CreateDefaultDraft();
            if (!FormationCircuitService.Validate(candidate, 30.0f, stressManuals).IsValid
                || FormationCircuitService.ValidateNodeAccess(
                    FormationV1Catalog.InputNodeId, 5.0f, stressManuals).Count != 0)
                throw new InvalidOperationException($"重复目录校验在第 {i + 1} 次失败");
            if (i % 8 == 7)
            {
                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
        }
        Check(true, "64 次目录/端口资格校验跨越强制 GC 保持稳定");

        var belowCounter = FormationCircuitService.Validate(fullDraft, 29.0f, FullManuals());
        Check(!belowCounter.IsValid && HasCode(belowCounter, "proficiency"), "造诣 29 不能使用三候枢");
        var invalidProficiency = FormationCircuitService.Validate(fullDraft, float.NaN, FullManuals());
        Check(!invalidProficiency.IsValid && HasCode(invalidProficiency, "proficiency"), "非有限造诣不能绕过资格检查");

        var missingManual = FormationCircuitService.Validate(fullDraft, 30.0f,
            new[] { "manual_small_circulation_input" });
        Check(!missingManual.IsValid && HasCode(missingManual, "missing_manual"), "缺少护元阵录会拒绝完整阵图");

        var inputManual = ResourceLoader.Load<FormationManualData>("res://resources/formations/小周天聚灵阵录.tres")!;
        var spellPort = inputManual.input_ports.Single(port => port.port_id.ToString() == "port_spell_played");
        var originalEvent = spellPort.battle_event;
        try
        {
            spellPort.battle_event = "invalid_event";
            Check(FormationCircuitService.ValidateNodeAccess(FormationV1Catalog.InputNodeId, 5.0f,
                    new[] { "manual_small_circulation_input" }).Any(issue => issue.Code == "invalid_port"),
                "真实输入阵录端口语义错误会拒绝单元件资格");
        }
        finally
        {
            spellPort.battle_event = originalEvent;
        }

        var inputAt5 = FormationCircuitService.ValidateNodeAccess(
            FormationV1Catalog.InputNodeId, 5.0f, new[] { "manual_small_circulation_input" });
        var counterAt29 = FormationCircuitService.ValidateNodeAccess(
            FormationV1Catalog.CounterNodeId, 29.0f, FullManuals());
        var counterAt30 = FormationCircuitService.ValidateNodeAccess(
            FormationV1Catalog.CounterNodeId, 30.0f, FullManuals());
        Check(inputAt5.Count == 0, "单元件入口认可真实输入端口及造诣 5");
        Check(counterAt29.Any(issue => issue.Code == "proficiency") && counterAt30.Count == 0,
            "单元件入口与整阵入口共享候枢 29/30 资格规则");

        var directDraft = FormationCircuitService.CloneForEditing(fullDraft);
        var counterIndex = directDraft.nodes.ToList().FindIndex(node => node.node_id.ToString() == FormationV1Catalog.CounterNodeId);
        directDraft.nodes.RemoveAt(counterIndex);
        directDraft.pulse_wires.Clear();
        directDraft.pulse_wires.Add(Wire(FormationV1Catalog.InputNodeId, FormationV1Catalog.ActuatorNodeId));
        directDraft.required_formation_proficiency = 999.0f;
        directDraft.required_manual_ids.Clear();
        var directAt5 = FormationCircuitService.Validate(directDraft, 5.0f, FullManuals());
        Check(directAt5.IsValid && directAt5.Metrics.UsedSlots == 2
              && directAt5.Metrics.Complexity == 2 && directAt5.Metrics.RequiredProficiency == 5.0f,
            "感应→护持直连按实际两件元件在造诣 5 通过");

        var empty = FormationV1Catalog.CreateDefaultDraft();
        empty.nodes.Clear();
        empty.pulse_wires.Clear();
        var emptyResult = FormationCircuitService.Validate(empty, 30.0f, FullManuals());
        Check(!emptyResult.IsValid && HasCode(emptyResult, "invalid_node"), "空节点/空脉纹输入安全拒绝且不抛异常");

        var disconnected = FormationV1Catalog.CreateDefaultDraft();
        disconnected.pulse_wires.Clear();
        Check(HasCode(FormationCircuitService.Validate(disconnected, 30.0f, FullManuals()), "disconnected"),
            "缺边链路被判为断连");

        var cycle = FormationV1Catalog.CreateDefaultDraft();
        cycle.pulse_wires.Add(Wire(FormationV1Catalog.ActuatorNodeId, FormationV1Catalog.InputNodeId));
        Check(HasCode(FormationCircuitService.Validate(cycle, 30.0f, FullManuals()), "cycle"),
            "回接脉纹被判为环路");

        var bypass = FormationV1Catalog.CreateDefaultDraft();
        bypass.pulse_wires.Add(Wire(FormationV1Catalog.InputNodeId, FormationV1Catalog.ActuatorNodeId));
        Check(HasCode(FormationCircuitService.Validate(bypass, 30.0f, FullManuals()), "invalid_wire"),
            "三节点链增加感应→护持旁路会被拒绝");

        var noLayers = FormationV1Catalog.CreateDefaultDraft();
        noLayers.hardware!.pulse_layers = 0;
        Check(HasCode(FormationCircuitService.Validate(noLayers, 30.0f, FullManuals()), "invalid_hardware"),
            "带脉纹的阵盘至少需要一层脉纹承载");

        var tooFewSlots = FormationV1Catalog.CreateDefaultDraft();
        tooFewSlots.hardware!.component_slots = 3;
        Check(HasCode(FormationCircuitService.Validate(tooFewSlots, 30.0f, FullManuals()), "slots"),
            "三候链路超出阵盘格位会被拒绝");
        var tooLittleComplexity = FormationV1Catalog.CreateDefaultDraft();
        tooLittleComplexity.hardware!.eye_complexity = 3;
        Check(HasCode(FormationCircuitService.Validate(tooLittleComplexity, 30.0f, FullManuals()), "complexity"),
            "三候链路超出阵眼复杂度会被拒绝");

        var exhausted = FormationV1Catalog.CreateDefaultDraft();
        exhausted.hardware!.source_capacity = 0;
        exhausted.hardware.source_recharge_per_turn = 0;
        exhausted.hardware.source_peak_output = 0;
        exhausted.hardware.spirit_link_peak_output = 0;
        exhausted.hardware.board_peak_load = 0;
        exhausted.hardware.board_material_tags.Clear();
        exhausted.hardware.ink_material_tags.Clear();
        exhausted.hardware.eye_material_tags.Clear();
        exhausted.hardware.source_material_tags.Clear();
        Check(FormationCircuitService.Validate(exhausted, 30.0f, FullManuals()).IsValid,
            "阵能/供能峰值不足保留为运行时启动失败，不伪装为结构错误");

        var spoofedNode = FormationV1Catalog.CreateDefaultDraft();
        spoofedNode.nodes.First(node => node.node_id.ToString() == FormationV1Catalog.ActuatorNodeId).effect_value = 99;
        Check(HasCode(FormationCircuitService.Validate(spoofedNode, 30.0f, FullManuals()), "invalid_node"),
            "外部篡改阵器效果数值会被固定模板语义拒绝");

        var hardware = new FormationHardwareData
        {
            component_slots = 4,
            pulse_layers = 1,
            eye_complexity = 4,
            source_capacity = 4,
            source_recharge_per_turn = 1,
            source_peak_output = 2,
            spirit_link_peak_output = 2,
            board_peak_load = 2
        };
        var tags = new Array<string>();
        foreach (var tag in new[] { "功用[通脉]", "功用[蕴灵]", "功用[聚灵]", "功用[纳气]", "功用[固本]", "功用[明心]" })
            tags.Add(tag);
        hardware.apply_material_tags(tags);
        var effectiveOnce = new[]
        {
            hardware.effective_source_capacity(), hardware.effective_source_recharge(), hardware.effective_source_peak(),
            hardware.effective_link_peak(), hardware.effective_board_load(), hardware.effective_eye_complexity()
        };
        hardware.apply_material_tags(tags);
        var effectiveTwice = new[]
        {
            hardware.effective_source_capacity(), hardware.effective_source_recharge(), hardware.effective_source_peak(),
            hardware.effective_link_peak(), hardware.effective_board_load(), hardware.effective_eye_complexity()
        };
        Check(effectiveOnce.SequenceEqual(new[] { 5, 2, 3, 3, 3, 5 })
              && effectiveTwice.SequenceEqual(effectiveOnce)
              && hardware.source_capacity == 4 && hardware.source_recharge_per_turn == 1,
            "重复应用材料标签保持幂等，原始硬件字段不被双加");

        var owner = new HumanData { formation_proficiency = 30.0f };
        owner.formation_manual_ids = FullManuals();
        var otherCircuit = new FormationCircuitData { circuit_id = "legacy_other_diagram" };
        owner.formation_circuits.Add(otherCircuit);
        owner.formation_circuits.Add(new FormationCircuitData { circuit_id = FormationV1Catalog.CircuitId });
        owner.formation_circuits.Add(new FormationCircuitData { circuit_id = FormationV1Catalog.CircuitId });
        fullDraft.required_formation_proficiency = 0.0f;
        fullDraft.required_manual_ids.Clear();
        Check(FormationCircuitService.TryApply(owner, fullDraft, out var appliedResult) && appliedResult.IsValid,
            "通过完整校验后原子装配示范阵");
        Check(owner.formation_circuits.Count(circuit => circuit.circuit_id.ToString() == FormationV1Catalog.CircuitId) == 1,
            "重复同 ID 阵图被替换为唯一记录");
        Check(ReferenceEquals(otherCircuit, owner.formation_circuits.Single(circuit => circuit.circuit_id.ToString() == "legacy_other_diagram")),
            "其他阵图记录保持原样");
        var applied = owner.formation_circuits.Single(circuit => circuit.circuit_id.ToString() == FormationV1Catalog.CircuitId);
        Check(applied.required_formation_proficiency == 30.0f
              && applied.required_manual_ids.Contains("manual_small_circulation_input")
              && applied.required_manual_ids.Contains("manual_guard_output"),
            "装配元数据由真实节点和真实资格重建");
        Check(!ReferenceEquals(applied, fullDraft) && !ReferenceEquals(applied.nodes[0], fullDraft.nodes[0]),
            "装配配置与编辑草稿深复制隔离");

        var rejectedOwner = new HumanData { formation_proficiency = 30.0f };
        rejectedOwner.formation_manual_ids.Add("manual_small_circulation_input");
        var unchanged = new FormationCircuitData { circuit_id = "keep_on_failure" };
        rejectedOwner.formation_circuits.Add(unchanged);
        Check(!FormationCircuitService.TryApply(rejectedOwner, fullDraft, out var rejectedResult)
              && HasCode(rejectedResult, "missing_manual")
              && ReferenceEquals(unchanged, rejectedOwner.formation_circuits[0]),
            "资格失败时不替换或污染已装配列表");

        var snapshotClone = FormationCircuitService.CloneCircuits(owner.formation_circuits);
        snapshotClone.Single(circuit => circuit.circuit_id.ToString() == FormationV1Catalog.CircuitId)
            .hardware!.board_peak_load = 77;
        Check(applied.hardware!.board_peak_load != 77, "阵图清单深复制包含嵌套硬件 Resource");

        var sourceBattleData = new BattleEntityData
        {
            formation_circuits = FormationCircuitService.CloneCircuits(owner.formation_circuits),
            formation_manual_ids = FullManuals(),
            combat_skill_slots_configured = true
        };
        var copiedBattleData = new BattleEntityData();
        copiedBattleData.copy_from(sourceBattleData);
        copiedBattleData.formation_circuits.Single(circuit => circuit.circuit_id.ToString() == FormationV1Catalog.CircuitId)
            .nodes[0].display_name = "快照副本改名";
        Check(sourceBattleData.formation_circuits.Single(circuit => circuit.circuit_id.ToString() == FormationV1Catalog.CircuitId)
                  .nodes[0].display_name != "快照副本改名",
            "BattleEntityData.copy_from 深复制阵图子资源");

        var character = new Character { entity_data = new HumanData() };
        AddChild(character);
        character.apply_battle_data(sourceBattleData);
        var characterData = (HumanData)character.entity_data!;
        characterData.formation_circuits.Single(circuit => circuit.circuit_id.ToString() == FormationV1Catalog.CircuitId)
            .nodes[0].display_name = "角色副本改名";
        Check(sourceBattleData.formation_circuits.Single(circuit => circuit.circuit_id.ToString() == FormationV1Catalog.CircuitId)
                  .nodes[0].display_name != "角色副本改名",
            "Character.apply_battle_data 深复制阵图子资源");
        var characterSnapshot = character.get_snapshot_data();
        characterSnapshot.formation_circuits.Single(circuit => circuit.circuit_id.ToString() == FormationV1Catalog.CircuitId)
            .hardware!.board_peak_load = 88;
        Check(characterData.formation_circuits.Single(circuit => circuit.circuit_id.ToString() == FormationV1Catalog.CircuitId)
                  .hardware!.board_peak_load != 88,
            "Character.get_snapshot_data 深复制阵图子资源");
        character.Free();

        VerifyV8RoundTrip(applied);
        VerifyMissingLayoutFieldsDefault();
    }

    private static void VerifyV8RoundTrip(FormationCircuitData circuit)
    {
        var player = new HumanData { formation_proficiency = 30.0f };
        player.formation_manual_ids = FullManuals();
        player.formation_circuits.Add(circuit);
        var save = new PersistentGameSave
        {
            format_version = PersistentGameSave.CurrentFormatVersion,
            slot_id = "formation-data-smoke-only",
            player_data = player
        };
        var path = "user://formation_data_smoke_v8.tres";
        Check(ResourceSaver.Save(save, path) == Error.Ok, "隔离 user:// 写入正式 v8 Resource");
        var loaded = ResourceLoader.Load<PersistentGameSave>(path, "", ResourceLoader.CacheMode.Ignore);
        Check(loaded is not null && loaded.format_version == 8
              && loaded.player_data?.formation_circuits.Count == 1,
            "v8 PersistentGameSave 读回阵图且不触发版本迁移");
        var restored = loaded!.player_data!.formation_circuits[0];
        Check(restored.required_formation_proficiency == 30.0f
              && restored.nodes.All(node => node.has_editor_position)
              && restored.nodes[1].editor_position == new Vector2(400, 180)
              && restored.pulse_wires.Count == 2,
            "v8 往返保留阵图门槛、节点布局与脉纹");
    }

    private static void VerifyMissingLayoutFieldsDefault()
    {
        const string path = "user://formation_data_smoke_legacy_node.tres";
        const string oldResource = """
            [gd_resource type="Resource" script_class="FormationNodeData" load_steps=2 format=3]

            [ext_resource type="Script" path="res://csharp/formation/FormationNodeData.cs" id="1"]

            [resource]
            script = ExtResource("1")
            node_id = &"spell_input"
            display_name = "术法感应枢"
            kind = 0
            """;
        var file = Godot.FileAccess.Open(path, Godot.FileAccess.ModeFlags.Write);
        if (file is null) throw new InvalidOperationException("无法写入隔离的旧节点资源夹具");
        file.StoreString(oldResource);
        file.Close();
        var loaded = ResourceLoader.Load<FormationNodeData>(path, "", ResourceLoader.CacheMode.Ignore);
        Check(loaded is not null && !loaded.has_editor_position && loaded.editor_position == Vector2.Zero,
            "旧 v8 节点缺少位置字段时使用默认位置并标记为未布局");
    }
}
