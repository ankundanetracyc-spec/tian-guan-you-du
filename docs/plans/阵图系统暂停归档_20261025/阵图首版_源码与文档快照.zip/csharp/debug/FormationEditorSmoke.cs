using Godot;
using System;
using System.Linq;
using System.Threading.Tasks;

/// <summary>隔离角色数据，透过视口鼠标/键盘输入验证阵法 GraphEdit，不接触正式存档。</summary>
public partial class FormationEditorSmoke : Control
{
    private const string CaptureRoot = "res://tmp/formation_editor";
    private BaigongPanel _panel = null!;
    private FormationEditorGraph _graph = null!;
    private Character _owner = null!;
    private int _changedEvents;
    private readonly System.Collections.Generic.Dictionary<ulong, Vector2> _lastMousePositions = [];

    private static void Check(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
        GD.Print("FORMATION_EDITOR_CHECK_OK " + message);
    }

    private async Task Frames(int count = 4)
    {
        for (var i = 0; i < count; i++) await ToSignal(GetTree(), SceneTree.SignalName.ProcessFrame);
    }

    private static System.Collections.Generic.IEnumerable<T> Nodes<T>(Node root) where T : Node
    {
        foreach (var child in root.GetChildren(includeInternal: true))
        {
            if (child is T match) yield return match;
            foreach (var nested in Nodes<T>(child)) yield return nested;
        }
    }

    private static void ParseInput(Window window, InputEvent input)
    {
        if (input is InputEventFromWindow fromWindow) fromWindow.WindowId = window.GetWindowId();
        Input.ParseInputEvent(input);
        Input.FlushBufferedEvents();
    }

    private void PushMotion(Vector2 point, MouseButtonMask mask = default)
        => PushMotion(GetViewport(), point, mask);

    private void PushMotion(Viewport viewport, Vector2 point, MouseButtonMask mask = default, bool parseGlobally = true)
    {
        var viewportId = viewport.GetInstanceId();
        var relative = _lastMousePositions.TryGetValue(viewportId, out var previous) ? point - previous : Vector2.Zero;
        if (parseGlobally) Input.WarpMouse(point);
        var input = new InputEventMouseMotion
        {
            Position = point,
            GlobalPosition = point,
            Relative = relative,
            ScreenRelative = relative,
            ButtonMask = mask
        };
        if (parseGlobally) ParseInput(viewport.GetWindow(), input);
        else viewport.PushInput(input, true);
        _lastMousePositions[viewportId] = point;
    }

    private void PushMouse(Vector2 point, MouseButton button, bool pressed)
        => PushMouse(GetViewport(), point, button, pressed);

    private void PushMouse(Viewport viewport, Vector2 point, MouseButton button, bool pressed, bool parseGlobally = true)
    {
        var input = new InputEventMouseButton
        {
            Position = point,
            GlobalPosition = point,
            ButtonIndex = button,
            Pressed = pressed,
            ButtonMask = pressed && button == MouseButton.Left ? MouseButtonMask.Left : (MouseButtonMask)0
        };
        if (parseGlobally) ParseInput(viewport.GetWindow(), input);
        else viewport.PushInput(input, true);
        _lastMousePositions[viewport.GetInstanceId()] = point;
    }

    private static Vector2 GlobalPoint(Control control, Vector2 localPoint)
        => control.GetGlobalTransformWithCanvas() * localPoint;

    private static Vector2 GraphPoint(FormationEditorGraph graph, Vector2 viewportLocalPoint)
        => graph.GetGlobalRect().Position + viewportLocalPoint;

    private async Task Click(Vector2 point, MouseButton button = MouseButton.Left)
        => await Click(GetViewport(), point, button);

    private async Task Click(Viewport viewport, Vector2 point, MouseButton button = MouseButton.Left, bool parseGlobally = true)
    {
        PushMotion(viewport, point, default, parseGlobally);
        PushMouse(viewport, point, button, true, parseGlobally);
        await Frames(1);
        PushMouse(viewport, point, button, false, parseGlobally);
        await Frames(4);
    }

    private async Task Click(Control control)
    {
        var visible = control.IsVisibleInTree();
        var rect = control.GetGlobalRect();
        Check(visible && rect.HasArea(), $"{control.Name} 可见且可点 visible={visible} rect={rect}");
        var viewport = control.GetViewport();
        var point = control.GetGlobalRect().GetCenter();
        if (viewport != GetViewport()) point += control.GetWindow().Position;
        await Click(GetViewport(), point);
    }

    private async Task Drag(Vector2 start, Vector2 end)
    {
        PushMotion(start);
        PushMouse(start, MouseButton.Left, true);
        await Frames(1);
        var distance = start.DistanceTo(end);
        var steps = Math.Max(1, Mathf.CeilToInt(distance / 5f));
        for (var step = 1; step <= steps; step++)
        {
            PushMotion(start.Lerp(end, step / (float)steps), MouseButtonMask.Left);
            if (step % 20 == 0 && step < steps) await Frames(1);
        }
        PushMotion(end, MouseButtonMask.Left);
        PushMouse(end, MouseButton.Left, false);
        await Frames(5);
    }

    private async Task Drag(Control source, Control target, Vector2 targetLocal)
        => await Drag(source.GetGlobalRect().GetCenter(), target is FormationEditorGraph graph
            ? GraphPoint(graph, targetLocal)
            : GlobalPoint(target, targetLocal));

    private async Task DragPort(GraphNode source, GraphNode target)
        => await Drag(GlobalPoint(source, source.GetOutputPortPosition(0)), GlobalPoint(target, target.GetInputPortPosition(0)));

    private async Task Wheel(Vector2 point, MouseButton direction, bool control = false)
    {
        PushMotion(point);
        ParseInput(GetWindow(), new InputEventMouseButton
        {
            Position = point,
            GlobalPosition = point,
            ButtonIndex = direction,
            Pressed = true,
            CtrlPressed = control
        });
        await Frames(1);
        ParseInput(GetWindow(), new InputEventMouseButton
        {
            Position = point,
            GlobalPosition = point,
            ButtonIndex = direction,
            Pressed = false,
            CtrlPressed = control
        });
        await Frames(4);
    }

    private async Task Capture(string name)
    {
        if (!OS.GetCmdlineUserArgs().Contains("--capture")) return;
        await Frames(2);
        await ToSignal(RenderingServer.Singleton, RenderingServer.SignalName.FramePostDraw);
        var folder = CaptureRoot + "/" + (GetViewportRect().Size.X < 1500 ? "1280x720" : "1920x1080");
        DirAccess.MakeDirRecursiveAbsolute(ProjectSettings.GlobalizePath(folder));
        var path = ProjectSettings.GlobalizePath(folder + "/" + name + ".png");
        var error = GetViewport().GetTexture().GetImage().SavePng(path);
        Check(error == Error.Ok, "截图写入 " + path);
    }

    public override async void _Ready()
    {
        try
        {
            var compact = OS.GetCmdlineUserArgs().Contains("--compact");
            var resolution = compact ? new Vector2I(1280, 720) : new Vector2I(1920, 1080);
            GetWindow().Mode = Window.ModeEnum.Windowed;
            GetWindow().Size = resolution;
            GetWindow().ContentScaleSize = resolution;
            SetAnchorsAndOffsetsPreset(LayoutPreset.FullRect);

            var layer = new CanvasLayer { Layer = 20 };
            AddChild(layer);
            _owner = new Character
            {
                entity_data = new HumanData
                {
                    entity_name = "阵图编辑隔离角色",
                    formation_proficiency = 30f,
                    formation_manual_ids = new Godot.Collections.Array<string>
                    {
                        "manual_small_circulation_input",
                        "manual_guard_output"
                    }
                }
            };
            _panel = new BaigongPanel { Name = "FormationEditorUnderTest" };
            _panel.FormationChanged += () => _changedEvents++;
            layer.AddChild(_panel);
            _panel.show_for(_owner);
            await Frames(10);

            _graph = Nodes<FormationEditorGraph>(_panel).Single();
            Check(Nodes<GraphNode>(_graph).Count() == 3, "初始草稿显示三类固定元件各一份");
            Check(_graph.IsNodeConnected("spell_input", 0, "third_spell_counter", 0), "默认输入至三候脉纹已加载");
            Check(_graph.IsNodeConnected("third_spell_counter", 0, "ward_actuator", 0), "默认三候至护持脉纹已加载");
            await Capture("01_三栏初始");

            var zoomOutButton = Nodes<Button>(_panel).Single(button => button.Text == "−");
            var zoomButton = Nodes<Button>(_panel).Single(button => button.Text == "＋");
            var zoomBefore = _graph.Zoom;
            await Click(zoomOutButton);
            Check(_graph.Zoom < zoomBefore, "缩小按钮通过实际输入缩小画布");
            zoomBefore = _graph.Zoom;
            await Click(zoomButton);
            Check(_graph.Zoom > zoomBefore, "放大按钮通过实际输入放大画布");

            var sensor = Nodes<GraphNode>(_graph).Single(node => node.Name == "spell_input");
            var oldSensorPosition = sensor.PositionOffset;
            var sensorCatalog = Nodes<FormationEditorCatalogDragItem>(_panel).Single(item => item.NodeId == "spell_input");
            var wheelPoint = _graph.GetGlobalRect().GetCenter();
            zoomBefore = _graph.Zoom;
            await Wheel(wheelPoint, MouseButton.WheelDown);
            Check(_graph.Zoom < zoomBefore, "GraphEdit 滚轮输入缩小画布");
            zoomBefore = _graph.Zoom;
            await Wheel(wheelPoint, MouseButton.WheelUp);
            Check(_graph.Zoom > zoomBefore, "GraphEdit 滚轮输入放大画布");
            var panBefore = _graph.ScrollOffset;
            await Wheel(wheelPoint, MouseButton.WheelDown, control: true);
            Check(_graph.ScrollOffset != panBefore, "GraphEdit Ctrl+滚轮输入平移画布");

            var releasePoint = new Vector2(84, 123) * _graph.Zoom;
            await Drag(sensorCatalog, _graph, releasePoint);
            sensor = Nodes<GraphNode>(_graph).Single(node => node.Name == "spell_input");
            Check(sensor.PositionOffset != oldSensorPosition, "目录条目经真实拖放移动画布元件");
            Check(sensor.Position.DistanceTo(releasePoint) <= 15f * _graph.Zoom,
                "缩放和平移后拖放的元件位置贴近释放点");

            var counter = Nodes<GraphNode>(_graph).Single(node => node.Name == "third_spell_counter");
            var inputPort = GlobalPoint(sensor, sensor.GetOutputPortPosition(0));
            var counterPort = GlobalPoint(counter, counter.GetInputPortPosition(0));
            await Click((inputPort + counterPort) * 0.5f);
            Check(_graph.SelectedWireText.StartsWith("已选脉纹：", StringComparison.Ordinal), "GraphEdit 视口点击选中了真实脉纹");
            var disconnect = Nodes<Button>(_panel).Single(button => button.Text == "断开所选脉纹");
            await Click(disconnect);
            Check(!_graph.IsNodeConnected("spell_input", 0, "third_spell_counter", 0), "真实控件操作断开脉纹");
            var saveButton = Nodes<Button>(_panel).Single(button => button.Text == "保存并装配");
            Check(saveButton.Disabled, "断开后实时校验阻止不完整草稿装配");

            sensor = Nodes<GraphNode>(_graph).Single(node => node.Name == "spell_input");
            counter = Nodes<GraphNode>(_graph).Single(node => node.Name == "third_spell_counter");
            await DragPort(sensor, counter);
            Check(_graph.IsNodeConnected("spell_input", 0, "third_spell_counter", 0), "GraphEdit 视口端口拖动重新连接脉纹");

            var ward = Nodes<GraphNode>(_graph).Single(node => node.Name == "ward_actuator");
            await DragPort(sensor, ward);
            Check(saveButton.Disabled, "多余控制脉纹由公共校验拒绝装配");
            var shortcutHandled = _panel.TryHandleFormationSaveShortcut(new InputEventKey
            {
                Keycode = Key.S,
                PhysicalKeycode = Key.S,
                CtrlPressed = true,
                Pressed = true
            });
            Check(shortcutHandled && _changedEvents == 0, "Ctrl+S 失败仍被编辑器消费且未装配");
            Check(_graph.SelectedWireText.StartsWith("已选脉纹：校验定位", StringComparison.Ordinal), "结构化 FromNodeId/ToNodeId 将校验失败定位到脉纹");
            var removeInvalidWire = Nodes<Button>(_panel).Single(button => button.Text == "断开所选脉纹");
            await Click(removeInvalidWire);
            Check(!saveButton.Disabled, "移除被定位的无效脉纹后校验恢复");

            ward = Nodes<GraphNode>(_graph).Single(node => node.Name == "ward_actuator");
            await Click(GlobalPoint(ward, ward.GetRect().Size * 0.5f));
            Check(ward.Selected, "真实点击选中护持元件");
            _graph.GrabFocus();
            ParseInput(GetWindow(), new InputEventKey { Keycode = Key.Delete, PhysicalKeycode = Key.Delete, Pressed = true });
            await Frames(8);
            ParseInput(GetWindow(), new InputEventKey { Keycode = Key.Delete, PhysicalKeycode = Key.Delete, Pressed = false });
            await Frames(4);
            Check(Nodes<GraphNode>(_graph).All(node => node.Name != "ward_actuator"), "Delete 键通过 GraphEdit 请求删除选中元件");
            Check(saveButton.Disabled, "删除元件后非法草稿不能装配");

            var wardCatalog = Nodes<FormationEditorCatalogDragItem>(_panel).Single(item => item.NodeId == "ward_actuator");
            var wardCanvasPosition = new Vector2(680, 180);
            await Drag(wardCatalog, _graph, wardCanvasPosition * _graph.Zoom - _graph.ScrollOffset);
            Check(Nodes<GraphNode>(_graph).Any(node => node.Name == "ward_actuator"), "目录拖放重新放置缺失的护持元件");
            counter = Nodes<GraphNode>(_graph).Single(node => node.Name == "third_spell_counter");
            ward = Nodes<GraphNode>(_graph).Single(node => node.Name == "ward_actuator");
            await DragPort(counter, ward);
            Check(_graph.IsNodeConnected("third_spell_counter", 0, "ward_actuator", 0), "GraphEdit 端口输入连接到护持阵器");
            Check(!saveButton.Disabled, "完整合法结构恢复装配资格");
            var human = (HumanData)_owner.entity_data!;
            var restoreSampleButton = Nodes<Button>(_panel).Single(button => button.Text == "恢复示范");
            await Click(restoreSampleButton);
            Check(Nodes<GraphNode>(_graph).Count() == 3
                && _graph.IsNodeConnected("spell_input", 0, "third_spell_counter", 0)
                && _graph.IsNodeConnected("third_spell_counter", 0, "ward_actuator", 0), "恢复示范按钮重建默认草稿结构");
            Check(_changedEvents == 0 && human.formation_circuits.Count == 0, "恢复示范只改草稿，没有立即装配");
            Check(!saveButton.Disabled, "恢复的合法示范仍需点击保存才装配");
            var centerButton = Nodes<Button>(_panel).Single(button => button.Text == "归中");
            await Click(centerButton);
            var graphRect = _graph.GetGlobalRect();
            var allNodesVisible = Nodes<GraphNode>(_graph).All(node =>
            {
                var rect = node.GetGlobalRect();
                return graphRect.HasPoint(rect.Position + Vector2.One) && graphRect.HasPoint(rect.End - Vector2.One);
            });
            Check(allNodesVisible, "归中按钮按节点范围适配视野且三枚元件完整可见");
            await Capture("02_归中完成");
            await Capture("02_真实交互后");

            await Click(saveButton);
            Check(_changedEvents == 1, "成功装配恰发一次 FormationChanged");
            Check(human.formation_circuits.Count(circuit => circuit.circuit_id.ToString() == FormationV1Catalog.CircuitId.ToString()) == 1,
                "保存将目标阵图装配到隔离角色且没有重复项");

            ward = Nodes<GraphNode>(_graph).Single(node => node.Name == "ward_actuator");
            var savedWardPosition = ward.PositionOffset;
            var postSaveDragStart = GlobalPoint(ward, new Vector2(70, 14));
            await Drag(postSaveDragStart, postSaveDragStart + new Vector2(60, 45));
            Check(Nodes<Label>(_panel).Any(label => label.Text.Contains("修改保留在独立草稿中")), "装配后的布局修改仍留在独立草稿");
            var cancelEditsButton = Nodes<Button>(_panel).Single(button => button.Text == "取消编辑");
            await Click(cancelEditsButton);
            ward = Nodes<GraphNode>(_graph).Single(node => node.Name == "ward_actuator");
            Check(ward.PositionOffset == savedWardPosition && _changedEvents == 1, "取消编辑恢复当前装配阵图且不发装配事件");
            Check(saveButton.Disabled, "取消编辑后草稿与已装配配置一致");
            var postCancelDragStart = GlobalPoint(ward, new Vector2(70, 14));
            await Drag(postCancelDragStart, postCancelDragStart + new Vector2(60, 45));
            Check(Nodes<Label>(_panel).Any(label => label.Text.Contains("修改保留在独立草稿中")), "重新编辑仍保留未装配状态");

            var pillTab = Nodes<Button>(_panel).Single(button => button.Text == "丹药");
            await Click(pillTab);
            var confirmation = Nodes<ConfirmationDialog>(_panel).Single();
            Check(confirmation.Visible && Nodes<FormationEditorGraph>(_panel).Count() == 1, "未保存时点击其他页签先弹出离开确认");
            await Click(confirmation.GetCancelButton());
            Check(!confirmation.Visible && Nodes<FormationEditorGraph>(_panel).Count() == 1, "切页确认中继续编辑会留在阵法页");
            await Click(pillTab);
            await Click(confirmation.GetOkButton());
            Check(!confirmation.Visible && Nodes<FormationEditorGraph>(_panel).Count() == 0
                && Nodes<Label>(_panel).Any(label => label.Text == "丹药"), "切页确认中丢弃草稿后进入目标说明页");
            Check(_changedEvents == 1 && human.formation_circuits.Count == 1, "切页丢弃不污染已装配配置或重复发送事件");
            await Click(Nodes<Button>(_panel).Single(button => button.Text == "阵法"));
            await Frames(5);
            _graph = Nodes<FormationEditorGraph>(_panel).Single();
            saveButton = Nodes<Button>(_panel).Single(button => button.Text == "保存并装配");
            ward = Nodes<GraphNode>(_graph).Single(node => node.Name == "ward_actuator");
            Check(saveButton.Disabled && ward.PositionOffset == savedWardPosition, "丢弃草稿后重建阵法编辑器并恢复已装配配置");
            var postDiscardDragStart = GlobalPoint(ward, new Vector2(70, 14));
            await Drag(postDiscardDragStart, postDiscardDragStart + new Vector2(60, 45));

            var closeButton = Nodes<Button>(_panel).Single(button => button.Text == "关闭");
            await Click(closeButton);
            confirmation = Nodes<ConfirmationDialog>(_panel).Single();
            Check(confirmation.Visible && _panel.Visible, "关闭草稿会显示离开确认");
            await Capture("03_离开确认");
            var saveAndLeave = Nodes<Button>(confirmation).Single(button => button.Text == "保存并离开");
            await Click(saveAndLeave);
            Check(!_panel.Visible && _changedEvents == 2, "保存并离开先成功装配、通知一次并关闭");

            // Isolated fixture: reopen a previously saved layout whose nodes are widely spaced.
            var savedCircuit = human.formation_circuits.Single(circuit => circuit.circuit_id.ToString() == FormationV1Catalog.CircuitId);
            var savedWard = savedCircuit.nodes.Single(node => node.node_id.ToString() == "ward_actuator");
            savedWard.editor_position = new Vector2(1680, 260);
            savedWard.has_editor_position = true;
            _panel.show_for(_owner);
            await Frames(8);
            _graph = Nodes<FormationEditorGraph>(_panel).Single();
            var reopenedGraphRect = _graph.GetGlobalRect();
            var reopenedNodesFit = Nodes<GraphNode>(_graph).All(node =>
            {
                var rect = node.GetGlobalRect();
                return reopenedGraphRect.HasPoint(rect.Position + Vector2.One) && reopenedGraphRect.HasPoint(rect.End - Vector2.One);
            });
            Check(_graph.Zoom <= (compact ? 0.55f : 0.82f), $"重开分散布局后归中自适应缩小画布 zoom={_graph.Zoom}");
            var reopenedNodeRects = string.Join("; ", Nodes<GraphNode>(_graph).Select(node => $"{node.Name}:{node.GetGlobalRect()}"));
            Check(reopenedNodesFit, "重开分散布局后所有元件适配在画布内 " + reopenedNodeRects);
            ward = Nodes<GraphNode>(_graph).Single(node => node.Name == "ward_actuator");
            var closeTestDragStart = GlobalPoint(ward, new Vector2(70, 14));
            Check(reopenedGraphRect.HasPoint(closeTestDragStart), "重开后护持元件标题点位于画布内");
            var positionBeforeCloseTest = ward.PositionOffset;
            await Drag(closeTestDragStart, closeTestDragStart + new Vector2(60, 45));
            Check(ward.PositionOffset != positionBeforeCloseTest,
                "重新打开后从画布内标题相对拖动护持元件会更新位置");
            closeButton = Nodes<Button>(_panel).Single(button => button.Text == "关闭");
            await Click(closeButton);
            confirmation = Nodes<ConfirmationDialog>(_panel).Single();
            Check(confirmation.Visible && _panel.Visible, "未保存草稿关闭时真实弹出三选项确认");
            await Click(confirmation.GetOkButton());
            Check(!_panel.Visible && _changedEvents == 2, "确认丢弃后关闭且不发装配事件");

            // 独立复核补充：自定义保存按钮切换页签时也必须关闭确认窗。
            _panel.show_for(_owner);
            await Frames(8);
            _graph = Nodes<FormationEditorGraph>(_panel).Single();
            counter = Nodes<GraphNode>(_graph).Single(node => node.Name == "third_spell_counter");
            var tabSaveStart = GlobalPoint(counter, new Vector2(70, 14));
            var tabSaveBefore = counter.PositionOffset;
            await Drag(tabSaveStart, tabSaveStart + new Vector2(45, 30));
            var tabSavePosition = counter.PositionOffset;
            Check(tabSavePosition != tabSaveBefore, "保存切页前真实拖动三候元件产生草稿修改");
            pillTab = Nodes<Button>(_panel).Single(button => button.Text == "丹药");
            await Click(pillTab);
            confirmation = Nodes<ConfirmationDialog>(_panel).Single();
            Check(confirmation.Visible, "保存切页前真实显示离开确认");
            var saveAndSwitch = Nodes<Button>(confirmation).Single(button => button.Text == "保存并离开");
            await Click(saveAndSwitch);
            Check(!confirmation.Visible && _panel.Visible && Nodes<FormationEditorGraph>(_panel).Count() == 0
                && Nodes<Label>(_panel).Any(label => label.Text == "丹药"), "保存并切页后关闭确认窗并显示目标页");
            Check(_changedEvents == 3 && human.formation_circuits.Single(c => c.circuit_id.ToString() == FormationV1Catalog.CircuitId)
                .nodes.Single(n => n.node_id == "third_spell_counter").editor_position == tabSavePosition,
                "保存切页恰通知一次且实际写入元件位置");
            GD.Print("FORMATION_EDITOR_SMOKE_OK " + resolution);
            GetTree().Quit();
        }
        catch (Exception error)
        {
            GD.PushError(error.ToString());
            GetTree().Quit(1);
        }
    }
}
