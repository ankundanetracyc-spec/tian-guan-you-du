using Godot;

/// <summary>百工总入口。阵法页以独立草稿编辑，只有通过公共服务校验后才装配。</summary>
public partial class BaigongPanel : Control
{
    private Character? _owner;
    private VBoxContainer? _body;
    private string _page = "阵法";
    private readonly System.Collections.Generic.Dictionary<string, Button> _tabs = [];
    private FormationCircuitData? _draft;
    private string _baselineFingerprint = "";
    private FormationEditorGraph? _graph;
    private Label? _validationLabel;
    private Label? _metricsLabel;
    private Label? _wireSelectionLabel;
    private Button? _disconnectButton;
    private Button? _deleteButton;
    private Button? _restoreSampleButton;
    private Button? _cancelEditsButton;
    private Button? _saveButton;
    private Label? _saveStatusLabel;
    private ConfirmationDialog? _closeConfirmation;
    private string? _pendingPage;
    private bool _leaveRequested;

    public event System.Action? FormationChanged;

    public override void _Ready()
    {
        SetAnchorsAndOffsetsPreset(LayoutPreset.FullRect);
        MouseFilter = MouseFilterEnum.Stop;
        Hide();
        build();
    }

    public void show_for(Character owner)
    {
        _owner = owner;
        ensure_draft();
        Show();
        select_page("阵法");
    }

    public void close()
    {
        if (!Visible) return;
        if (is_dirty())
        {
            request_leave(null);
            return;
        }
        finish_close();
    }

    /// <summary>供 MainScene 在通用保存之前调用；失败也消费编辑器内的 Ctrl+S。</summary>
    public bool TryHandleFormationSaveShortcut(InputEvent input)
    {
        if (!Visible || _page != "阵法" || input is not InputEventKey
            { Pressed: true, Echo: false, Keycode: Key.S, CtrlPressed: true }) return false;
        _ = save_and_install();
        return true;
    }

    private void build()
    {
        var shade = new ColorRect { Color = new Color(0.02f, 0.035f, 0.03f, 0.72f), MouseFilter = MouseFilterEnum.Stop };
        shade.SetAnchorsAndOffsetsPreset(LayoutPreset.FullRect);
        AddChild(shade);

        var frame = new PanelContainer { Name = "BaigongFrame", MouseFilter = MouseFilterEnum.Stop };
        frame.SetAnchorsAndOffsetsPreset(LayoutPreset.FullRect);
        frame.OffsetLeft = 22;
        frame.OffsetTop = 18;
        frame.OffsetRight = -22;
        frame.OffsetBottom = -18;
        frame.AddThemeStyleboxOverride("panel", paper_frame_style());
        AddChild(frame);

        var outer = new HBoxContainer { Name = "BaigongColumns" };
        outer.AddThemeConstantOverride("separation", 16);
        frame.AddChild(outer);

        var tabBar = new VBoxContainer { CustomMinimumSize = new Vector2(126, 0) };
        tabBar.AddThemeConstantOverride("separation", 9);
        outer.AddChild(tabBar);
        tabBar.AddChild(title("百工", 26, new Color("#e6e1cb")));
        var subtitle = muted("传承与器物");
        subtitle.AddThemeColorOverride("font_color", new Color("#c9d2bf"));
        tabBar.AddChild(subtitle);
        foreach (var page in new[] { "法宝", "丹药", "符箓", "阵法" })
        {
            var tab = new Button { Text = page, CustomMinimumSize = new Vector2(116, 46), FocusMode = FocusModeEnum.All };
            tab.AddThemeStyleboxOverride("normal", tab_style());
            tab.AddThemeStyleboxOverride("hover", tab_style(true));
            tab.AddThemeColorOverride("font_color", new Color("#42483b"));
            tab.Pressed += () => select_page(page);
            _tabs[page] = tab;
            tabBar.AddChild(tab);
        }
        tabBar.AddChild(new Control { SizeFlagsVertical = SizeFlags.ExpandFill });
        var close = new Button { Text = "关闭", CustomMinimumSize = new Vector2(116, 42), FocusMode = FocusModeEnum.All };
        close.AddThemeStyleboxOverride("normal", tab_style());
        close.AddThemeColorOverride("font_color", new Color("#42483b"));
        close.Pressed += this.close;
        tabBar.AddChild(close);

        var divider = new ColorRect { Color = new Color("#7b6842", 0.55f), CustomMinimumSize = new Vector2(1, 0), MouseFilter = MouseFilterEnum.Ignore };
        outer.AddChild(divider);
        _body = new VBoxContainer { Name = "BaigongBody", SizeFlagsHorizontal = SizeFlags.ExpandFill, SizeFlagsVertical = SizeFlags.ExpandFill };
        _body.AddThemeConstantOverride("separation", 12);
        outer.AddChild(_body);
    }

    private void select_page(string page)
    {
        if (_page == "阵法" && page != "阵法" && is_dirty())
        {
            request_leave(page);
            return;
        }
        apply_page(page);
    }

    private void apply_page(string page)
    {
        _page = page;
        foreach (var (name, tab) in _tabs)
        {
            tab.Disabled = name == page;
            tab.Modulate = name == page ? new Color("#a17b3b") : Colors.White;
        }
        if (_body is null) return;
        _graph = null;
        _validationLabel = null;
        _metricsLabel = null;
        _wireSelectionLabel = null;
        _disconnectButton = null;
        _deleteButton = null;
        _restoreSampleButton = null;
        _cancelEditsButton = null;
        _saveButton = null;
        _saveStatusLabel = null;
        clear(_body);
        if (page == "阵法")
        {
            ensure_draft();
            build_formation();
        }
        else build_placeholder(page);
    }

    private void build_placeholder(string page)
    {
        _body!.AddChild(title(page, 27, new Color("#354337")));
        _body.AddChild(muted($"{page}的具体制作规则尚未定稿。\n本页保留在百工入口中，待对应专题确认后接入。"));
    }

    private void build_formation()
    {
        if (_draft is null) return;
        var (proficiency, _) = owner_qualifications();
        var heading = new HBoxContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill };
        heading.AddChild(title("阵法 · 云息示范阵", 25, new Color("#e6e1cb")));
        heading.AddChild(new Label
        {
            Text = $"阵道造诣 {proficiency:0}　·　当前仅编辑此示范阵",
            HorizontalAlignment = HorizontalAlignment.Right,
            SizeFlagsHorizontal = SizeFlags.ExpandFill,
            VerticalAlignment = VerticalAlignment.Center
        });
        _body!.AddChild(heading);
        var instructions = muted("拖动左侧元件到阵盘；拖动节点调整位置；滚轮缩放、Ctrl+滚轮平移。脉纹连接信号，阵源与灵络线路只读。");
        instructions.AddThemeColorOverride("font_color", new Color("#c9d2bf"));
        _body.AddChild(instructions);

        var columns = new HBoxContainer { SizeFlagsVertical = SizeFlags.ExpandFill, SizeFlagsHorizontal = SizeFlags.ExpandFill };
        columns.AddThemeConstantOverride("separation", 12);
        _body.AddChild(columns);

        var libraryColumn = column("阵法录与元件", 244);
        columns.AddChild(libraryColumn.panel);
        var libraryScroll = new ScrollContainer { SizeFlagsVertical = SizeFlags.ExpandFill, SizeFlagsHorizontal = SizeFlags.ExpandFill };
        libraryColumn.content.AddChild(libraryScroll);
        var library = new VBoxContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill };
        library.AddThemeConstantOverride("separation", 7);
        libraryScroll.AddChild(library);
        library.AddChild(section_label("阵法录端口"));
        var inputIssues = node_access_issues("spell_input");
        var wardIssues = node_access_issues("ward_actuator");
        var inputManual = FormationV1Catalog.LoadInputManual();
        var outputManual = FormationV1Catalog.LoadOutputManual();
        library.AddChild(qualification_item($"术法输入 · 《{inputManual.manual_name}》", inputIssues.Count == 0, inputIssues.Count == 0 ? node_summary("spell_input") : access_reason(inputIssues)));
        library.AddChild(qualification_item($"护持输出 · 《{outputManual.manual_name}》", wardIssues.Count == 0, wardIssues.Count == 0 ? node_summary("ward_actuator") : access_reason(wardIssues)));
        library.AddChild(section_label("元件目录 · 拖入阵盘"));
        foreach (var entry in new[] { ("spell_input", "术法感应枢", 0), ("third_spell_counter", "三候枢", 3), ("ward_actuator", "护持阵器", 10) })
        {
            var issues = node_access_issues(entry.Item1);
            var ready = issues.Count == 0;
            library.AddChild(catalog_item(entry.Item1, entry.Item2, entry.Item3, ready,
                ready ? "拖入阵盘可放置或移动此元件。" : "未解锁：" + access_reason(issues), node_summary(entry.Item1)));
        }
        library.AddChild(muted("每类最多一件。已在阵盘上的元件拖入后会移动位置。"));

        var boardColumn = column("阵盘 · 脉纹编辑", 0);
        boardColumn.panel.SizeFlagsHorizontal = SizeFlags.ExpandFill;
        columns.AddChild(boardColumn.panel);
        var graphToolbar = new HBoxContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill };
        graphToolbar.AddThemeConstantOverride("separation", 6);
        boardColumn.content.AddChild(graphToolbar);
        var zoomOut = small_button("−");
        zoomOut.TooltipText = "缩小阵盘";
        zoomOut.Pressed += () => { if (_graph is not null) _graph.Zoom = Mathf.Max(_graph.ZoomMin, _graph.Zoom / _graph.ZoomStep); };
        graphToolbar.AddChild(zoomOut);
        var zoomIn = small_button("＋");
        zoomIn.TooltipText = "放大阵盘";
        zoomIn.Pressed += () => { if (_graph is not null) _graph.Zoom = Mathf.Min(_graph.ZoomMax, _graph.Zoom * _graph.ZoomStep); };
        graphToolbar.AddChild(zoomIn);
        var center = small_button("归中");
        center.Pressed += () => _graph?.CenterGraph();
        graphToolbar.AddChild(center);
        graphToolbar.AddChild(new Control { SizeFlagsHorizontal = SizeFlags.ExpandFill });
        _disconnectButton = small_button("断开所选脉纹");
        _disconnectButton.Disabled = true;
        _disconnectButton.Pressed += () => _graph?.DisconnectSelectedWire();
        graphToolbar.AddChild(_disconnectButton);
        _deleteButton = small_button("删除选中元件");
        _deleteButton.Pressed += () => _graph?.DeleteSelectedNodes();
        graphToolbar.AddChild(_deleteButton);

        var scene = GD.Load<PackedScene>("res://tscn/panel/FormationEditorGraph.tscn");
        if (scene?.Instantiate() is FormationEditorGraph graph)
        {
            _graph = graph;
            _graph.SizeFlagsHorizontal = SizeFlags.ExpandFill;
            _graph.SizeFlagsVertical = SizeFlags.ExpandFill;
            _graph.CustomMinimumSize = new Vector2(460, 340);
            _graph.CanDropNode = can_use_node;
            _graph.DraftEdited += on_graph_edited;
            _graph.SelectionChanged += on_graph_selection_changed;
            boardColumn.content.AddChild(_graph);
            _graph.BindDraft(_draft);
        }
        else
        {
            boardColumn.content.AddChild(muted("阵盘画布加载失败；请检查 FormationEditorGraph.tscn。"));
        }

        _wireSelectionLabel = muted("未选中脉纹。点选线段后可按 Delete 断开；Delete 也可删除选中元件。右键仍由全局路由返回。\n" +
            "阵源 ━━━ 灵络 ━━━ 护持阵器（只读供能示意）");
        boardColumn.content.AddChild(_wireSelectionLabel);

        var statusColumn = column("结构校验与硬件", 260);
        columns.AddChild(statusColumn.panel);
        var statusScroll = new ScrollContainer { SizeFlagsVertical = SizeFlags.ExpandFill, SizeFlagsHorizontal = SizeFlags.ExpandFill };
        statusColumn.content.AddChild(statusScroll);
        var statusBody = new VBoxContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill };
        statusBody.AddThemeConstantOverride("separation", 7);
        statusScroll.AddChild(statusBody);
        _validationLabel = muted("");
        statusBody.AddChild(_validationLabel);
        _metricsLabel = muted("");
        statusBody.AddChild(_metricsLabel);
        statusBody.AddChild(section_label("固定规则"));
        var counterConfig = FormationV1Catalog.CreateNode("third_spell_counter");
        var wardConfig = FormationV1Catalog.CreateNode("ward_actuator");
        statusBody.AddChild(muted($"三候间隔 {counterConfig.interval} · 阵器消耗 {wardConfig.energy_cost} · 护持效果 {wardConfig.effect_value}\n元件属性、硬件供能参数与灵络线路不可编辑。"));
        statusBody.AddChild(muted("阵脉只传信号，不形成能量或费用。"));
        statusBody.AddChild(muted("每个完整战斗轮，阵器最多成功启动一次；三候计数跨轮保留。"));
        var actions = new VBoxContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill };
        actions.AddThemeConstantOverride("separation", 6);
        statusColumn.content.AddChild(actions);
        _restoreSampleButton = small_button("恢复示范");
        _restoreSampleButton.TooltipText = "将当前编辑草稿恢复为云息示范阵；不会立即装配。";
        _restoreSampleButton.SizeFlagsHorizontal = SizeFlags.ExpandFill;
        _restoreSampleButton.Pressed += restore_sample_draft;
        actions.AddChild(_restoreSampleButton);
        _cancelEditsButton = small_button("取消编辑");
        _cancelEditsButton.TooltipText = "放弃本次草稿修改并恢复当前已装配配置。";
        _cancelEditsButton.SizeFlagsHorizontal = SizeFlags.ExpandFill;
        _cancelEditsButton.Pressed += cancel_formation_edits;
        actions.AddChild(_cancelEditsButton);
        _saveButton = new Button { Text = "保存并装配", CustomMinimumSize = new Vector2(0, 44), SizeFlagsHorizontal = SizeFlags.ExpandFill, FocusMode = FocusModeEnum.All };
        _saveButton.AddThemeStyleboxOverride("normal", save_button_style());
        _saveButton.AddThemeColorOverride("font_color", new Color("#263b31"));
        _saveButton.Pressed += () => { _ = save_and_install(); };
        actions.AddChild(_saveButton);
        _saveStatusLabel = muted("未装配的修改仅在此草稿中。保存通过完整校验后才替换已装配阵图。需可用阵法录与造诣。 ");
        actions.AddChild(_saveStatusLabel);

        update_formation_state();
    }

    private void ensure_draft()
    {
        if (_draft is not null) return;
        var human = _owner?.entity_data as HumanData;
        var equipped = human?.formation_circuits.FirstOrDefault(c => c is not null && c.circuit_id.ToString() == FormationV1Catalog.CircuitId);
        var source = equipped ?? FormationV1Catalog.CreateDefaultDraft();
        _draft = FormationCircuitService.CloneForEditing(source);
        _baselineFingerprint = fingerprint(_draft);
    }

    private void on_graph_edited()
    {
        if (_draft is null) return;
        update_formation_state();
    }

    private void restore_sample_draft()
    {
        _draft = FormationCircuitService.CloneForEditing(FormationV1Catalog.CreateDefaultDraft());
        _graph?.BindDraft(_draft);
        update_formation_state();
    }

    private void cancel_formation_edits()
    {
        if (_owner?.entity_data is not HumanData human) return;
        var installed = human.formation_circuits.FirstOrDefault(circuit =>
            circuit is not null && circuit.circuit_id.ToString() == FormationV1Catalog.CircuitId);
        var source = installed ?? FormationV1Catalog.CreateDefaultDraft();
        _draft = FormationCircuitService.CloneForEditing(source);
        _baselineFingerprint = fingerprint(_draft);
        _graph?.BindDraft(_draft);
        update_formation_state();
    }

    private void on_graph_selection_changed(string message)
    {
        if (_wireSelectionLabel is not null)
            _wireSelectionLabel.Text = $"{message}\n阵源 ━━━ 灵络 ━━━ 护持阵器（只读供能示意）";
        if (_disconnectButton is not null) _disconnectButton.Disabled = !message.StartsWith("已选脉纹：", System.StringComparison.Ordinal);
    }

    private void update_formation_state()
    {
        if (_draft is null || _validationLabel is null || _metricsLabel is null || _saveButton is null) return;
        var (proficiency, manuals) = owner_qualifications();
        var result = FormationCircuitService.Validate(_draft, proficiency, manuals);
        _validationLabel.Text = result.IsValid
            ? "结构校验通过：可保存此配置。"
            : "当前无法装配：\n" + string.Join("\n", result.Issues.Select(issue => "· " + issue.Message));
        _validationLabel.AddThemeColorOverride("font_color", result.IsValid ? new Color("#3d704f") : new Color("#913f35"));
        var m = result.Metrics;
        _metricsLabel.Text = $"阵盘格位　{m.UsedSlots} / {m.SlotCapacity}\n" +
            $"阵眼复杂度　{m.Complexity} / {m.ComplexityCapacity}\n" +
            $"阵源容量　{m.SourceCapacity} · 每轮回复 {m.SourceRechargePerRound}\n" +
            $"阵源瞬时峰值　{m.SourcePeak}\n" +
            $"灵络峰值　{m.LinkPeak}\n" +
            $"阵盘峰值负荷　{m.BoardLoad}\n" +
            $"最低所需造诣　{m.RequiredProficiency:0}";
        _metricsLabel.AddThemeColorOverride("font_color", new Color("#3c4339"));
        var human = _owner?.entity_data as HumanData;
        var installed = human?.formation_circuits.Any(c => c is not null && c.circuit_id.ToString() == FormationV1Catalog.CircuitId) == true;
        var dirty = is_dirty();
        if (_restoreSampleButton is not null)
        {
            var sampleFingerprint = fingerprint(FormationV1Catalog.CreateDefaultDraft());
            _restoreSampleButton.Disabled = fingerprint(_draft) == sampleFingerprint;
        }
        if (_cancelEditsButton is not null) _cancelEditsButton.Disabled = !dirty;
        _saveButton.Disabled = !result.IsValid || human is null || (!dirty && installed);
        if (_saveStatusLabel is not null)
        {
            _saveStatusLabel.Text = installed && !dirty
                ? "当前配置已装配。"
                : installed ? "修改保留在独立草稿中，装配后才影响战斗。" : "尚未装配；保存通过校验后写入此角色。";
        }
    }

    private bool save_and_install()
    {
        if (_draft is null || _owner?.entity_data is not HumanData human) return false;
        var changed = is_dirty() || !human.formation_circuits.Any(c => c is not null && c.circuit_id.ToString() == FormationV1Catalog.CircuitId);
        if (!FormationCircuitService.TryApply(human, _draft, out var result))
        {
            if (_validationLabel is not null)
            {
                _validationLabel.Text = "装配失败：\n" + string.Join("\n", result.Issues.Select(issue => $"· {issue.Code}：{issue.Message}"));
                _validationLabel.AddThemeColorOverride("font_color", new Color("#913f35"));
            }
            var locatedIssue = result.Issues.FirstOrDefault(issue =>
                !string.IsNullOrWhiteSpace(issue.NodeId) ||
                (!string.IsNullOrWhiteSpace(issue.FromNodeId) && !string.IsNullOrWhiteSpace(issue.ToNodeId)));
            if (locatedIssue is not null) _graph?.FocusValidationIssue(locatedIssue);
            return false;
        }
        _baselineFingerprint = fingerprint(_draft);
        if (_saveStatusLabel is not null) _saveStatusLabel.Text = "装配已完成；运行时阵能和计数仍由战斗管理。";
        if (changed) FormationChanged?.Invoke();
        update_formation_state();
        return true;
    }

    private bool can_use_node(string nodeId)
    {
        return node_access_issues(nodeId).Count == 0;
    }

    private System.Collections.Generic.IReadOnlyList<FormationValidationIssue> node_access_issues(string nodeId)
    {
        var (proficiency, manuals) = owner_qualifications();
        return FormationCircuitService.ValidateNodeAccess(nodeId, proficiency, manuals);
    }

    private static string access_reason(System.Collections.Generic.IReadOnlyList<FormationValidationIssue> issues) =>
        string.Join("；", issues.Select(issue => issue.Message));

    private static string node_summary(string nodeId)
    {
        var node = FormationV1Catalog.CreateNode(nodeId);
        return node.kind switch
        {
            FormationNodeData.NodeKind.INPUT => $"实际付费施术 · {node.complexity_cost()} 复杂度",
            FormationNodeData.NodeKind.COUNTER => $"间隔 {node.interval} · {node.complexity_cost()} 复杂度",
            FormationNodeData.NodeKind.ACTUATOR => $"阵能消耗 {node.energy_cost} · 效果 {node.effect_value} · {node.complexity_cost()} 复杂度",
            _ => $"{node.complexity_cost()} 复杂度"
        };
    }

    private (float proficiency, Godot.Collections.Array<string> manuals) owner_qualifications()
    {
        if (_owner?.entity_data is not HumanData data) return (0f, []);
        var proficiency = _owner.entity_data.Get("formation_proficiency").AsSingle();
        return (proficiency, data.formation_manual_ids ?? []);
    }

    private void finish_close()
    {
        _closeConfirmation?.Hide();
        _leaveRequested = false;
        _pendingPage = null;
        _draft = null;
        _baselineFingerprint = "";
        _graph = null;
        Hide();
    }

    private void request_leave(string? page)
    {
        _leaveRequested = true;
        _pendingPage = page;
        _closeConfirmation ??= make_close_confirmation();
        _closeConfirmation.DialogText = page is null
            ? "当前草稿有未装配的修改。离开前请选择保存、丢弃或继续编辑。"
            : "当前草稿有未装配的修改。切换页面前请选择保存、丢弃或继续编辑。";
        _closeConfirmation.PopupCentered(new Vector2I(500, 205));
    }

    private void cancel_pending_leave()
    {
        _leaveRequested = false;
        _pendingPage = null;
    }

    private void discard_and_continue()
    {
        cancel_formation_edits();
        continue_pending_leave();
    }

    private void continue_pending_leave()
    {
        if (!_leaveRequested) return;
        _closeConfirmation?.Hide();
        var page = _pendingPage;
        _leaveRequested = false;
        _pendingPage = null;
        if (page is null) finish_close();
        else apply_page(page);
    }

    private ConfirmationDialog make_close_confirmation()
    {
        var dialog = new ConfirmationDialog
        {
            Title = "离开阵法编辑",
            DialogText = "当前草稿有未装配的修改。离开前请选择保存、丢弃或继续编辑。",
            OkButtonText = "丢弃草稿",
            CancelButtonText = "继续编辑",
            DialogCloseOnEscape = false,
            DialogAutowrap = true
        };
        dialog.Confirmed += discard_and_continue;
        dialog.Canceled += cancel_pending_leave;
        var saveAndLeave = dialog.AddButton("保存并离开", true);
        saveAndLeave.Pressed += () =>
        {
            if (save_and_install()) continue_pending_leave();
        };
        AddChild(dialog);
        return dialog;
    }

    private bool is_dirty() => _draft is not null && fingerprint(_draft) != _baselineFingerprint;

    private static string fingerprint(FormationCircuitData data)
    {
        var nodeParts = data.nodes
            .Where(node => node is not null)
            .Select(node => $"{node.node_id}:{effective_position(node).X:0.##},{effective_position(node).Y:0.##}")
            .OrderBy(value => value, System.StringComparer.Ordinal);
        var wireParts = data.pulse_wires
            .Select(wire => $"{wire.from_node_id}->{wire.to_node_id}")
            .OrderBy(value => value, System.StringComparer.Ordinal);
        return string.Join("|", nodeParts) + "/" + string.Join("|", wireParts);
    }

    private static Vector2 effective_position(FormationNodeData node) => node.has_editor_position
        ? node.editor_position
        : node.node_id.ToString() switch
        {
            "spell_input" => new Vector2(16, 150),
            "third_spell_counter" => new Vector2(210, 150),
            "ward_actuator" => new Vector2(404, 150),
            _ => Vector2.Zero
        };

    private (PanelContainer panel, VBoxContainer content) column(string heading, float width)
    {
        var panel = new PanelContainer
        {
            CustomMinimumSize = new Vector2(width, 0),
            SizeFlagsHorizontal = width > 0 ? SizeFlags.ShrinkBegin : SizeFlags.ExpandFill,
            SizeFlagsVertical = SizeFlags.ExpandFill,
            MouseFilter = MouseFilterEnum.Stop
        };
        panel.AddThemeStyleboxOverride("panel", card_style());
        var content = new VBoxContainer { SizeFlagsHorizontal = SizeFlags.ExpandFill, SizeFlagsVertical = SizeFlags.ExpandFill };
        content.AddThemeConstantOverride("separation", 8);
        panel.AddChild(content);
        content.AddChild(title(heading, 17, new Color("#354337")));
        var rule = new ColorRect { Color = new Color("#8b7546", 0.45f), CustomMinimumSize = new Vector2(0, 1), MouseFilter = MouseFilterEnum.Ignore };
        content.AddChild(rule);
        return (panel, content);
    }

    private Control catalog_item(string id, string name, int atlasCell, bool ready, string detail, string subline)
    {
        var line = new VBoxContainer();
        line.AddThemeConstantOverride("separation", 2);
        var button = new FormationEditorCatalogDragItem
        {
            NodeId = id,
            Text = name,
            Disabled = !ready,
            CustomMinimumSize = new Vector2(0, 42),
            SizeFlagsHorizontal = SizeFlags.ExpandFill,
            FocusMode = FocusModeEnum.All,
            TooltipText = detail,
            Icon = catalog_icon(atlasCell),
            ExpandIcon = true
        };
        button.AddThemeStyleboxOverride("normal", catalog_button_style(ready));
        button.AddThemeStyleboxOverride("hover", catalog_button_style(ready, true));
        button.AddThemeColorOverride("font_color", ready ? new Color("#344537") : new Color("#7d7c70"));
        button.AddThemeColorOverride("font_disabled_color", new Color("#878578"));
        line.AddChild(button);
        var detailLine = muted(detail);
        detailLine.AddThemeColorOverride("font_color", ready ? new Color("#555a4e") : new Color("#8e554c"));
        line.AddChild(detailLine);
        line.AddChild(muted(subline));
        return line;
    }

    private static Texture2D? catalog_icon(int cell)
    {
        var atlas = ResourceLoader.Load<Texture2D>("res://textures/ui/formation/formation_logic_atlas_v1.png");
        if (atlas is null) return null;
        const float cellWidth = 362f;
        const float cellHeight = 362f;
        var region = new AtlasTexture { Atlas = atlas, Region = new Rect2((cell % 4) * cellWidth, (cell / 4) * cellHeight, cellWidth, cellHeight) };
        return region;
    }

    private static Control qualification_item(string name, bool ready, string detail)
    {
        var box = new VBoxContainer();
        var label = title(ready ? name : $"未解锁 · {name}", 14, ready ? new Color("#405e48") : new Color("#875045"));
        box.AddChild(label);
        box.AddChild(muted(detail));
        return box;
    }

    private static Label section_label(string text) => title(text, 14, new Color("#886937"));

    private Button small_button(string text)
    {
        var button = new Button { Text = text, CustomMinimumSize = new Vector2(0, 34), FocusMode = FocusModeEnum.All };
        button.AddThemeStyleboxOverride("normal", tab_style());
        button.AddThemeColorOverride("font_color", new Color("#38483a"));
        return button;
    }

    private static Label title(string text, int size, Color color)
    {
        var label = new Label { Text = text };
        label.AddThemeFontSizeOverride("font_size", size);
        label.AddThemeColorOverride("font_color", color);
        return label;
    }

    private static Label muted(string text)
    {
        var label = new Label { Text = text, AutowrapMode = TextServer.AutowrapMode.WordSmart };
        label.AddThemeColorOverride("font_color", new Color("#55594e"));
        label.AddThemeFontSizeOverride("font_size", 13);
        return label;
    }

    private static void clear(Node node)
    {
        foreach (var child in node.GetChildren())
        {
            node.RemoveChild(child);
            child.QueueFree();
        }
    }

    private static StyleBoxTexture paper_frame_style()
    {
        return new StyleBoxTexture
        {
            Texture = ResourceLoader.Load<Texture2D>("res://textures/ui/world_hud_20261011/paper_panel_v1.png"),
            TextureMarginLeft = 34,
            TextureMarginRight = 34,
            TextureMarginTop = 34,
            TextureMarginBottom = 34,
            DrawCenter = true,
            ContentMarginLeft = 20,
            ContentMarginRight = 20,
            ContentMarginTop = 16,
            ContentMarginBottom = 16
        };
    }

    private static StyleBoxFlat card_style() => new()
    {
        BgColor = new Color("#efe9d7"), BorderColor = new Color("#a38d5d"),
        BorderWidthLeft = 1, BorderWidthTop = 1, BorderWidthRight = 1, BorderWidthBottom = 1,
        CornerRadiusTopLeft = 6, CornerRadiusTopRight = 6, CornerRadiusBottomLeft = 6, CornerRadiusBottomRight = 6,
        ContentMarginLeft = 12, ContentMarginRight = 12, ContentMarginTop = 10, ContentMarginBottom = 10
    };

    private static StyleBoxFlat tab_style(bool hover = false) => new()
    {
        BgColor = hover ? new Color("#e8ddbf") : new Color("#e2d8bc"),
        BorderColor = new Color("#9b8250"),
        BorderWidthLeft = 1, BorderWidthTop = 1, BorderWidthRight = 1, BorderWidthBottom = 1,
        CornerRadiusTopLeft = 5, CornerRadiusTopRight = 5, CornerRadiusBottomLeft = 5, CornerRadiusBottomRight = 5,
        ContentMarginLeft = 10, ContentMarginRight = 10, ContentMarginTop = 8, ContentMarginBottom = 8
    };

    private static StyleBoxFlat catalog_button_style(bool ready, bool hover = false) => new()
    {
        BgColor = !ready ? new Color("#d8d1bf") : hover ? new Color("#e0e6cf") : new Color("#e8e1cc"),
        BorderColor = ready ? new Color("#9d8c60") : new Color("#b0a894"),
        BorderWidthLeft = 1, BorderWidthTop = 1, BorderWidthRight = 1, BorderWidthBottom = 1,
        CornerRadiusTopLeft = 4, CornerRadiusTopRight = 4, CornerRadiusBottomLeft = 4, CornerRadiusBottomRight = 4,
        ContentMarginLeft = 7, ContentMarginRight = 7, ContentMarginTop = 5, ContentMarginBottom = 5
    };

    private static StyleBoxFlat save_button_style() => new()
    {
        BgColor = new Color("#c6d1a7"), BorderColor = new Color("#687949"),
        BorderWidthLeft = 1, BorderWidthTop = 1, BorderWidthRight = 1, BorderWidthBottom = 1,
        CornerRadiusTopLeft = 5, CornerRadiusTopRight = 5, CornerRadiusBottomLeft = 5, CornerRadiusBottomRight = 5,
        ContentMarginLeft = 14, ContentMarginRight = 14, ContentMarginTop = 8, ContentMarginBottom = 8
    };
}
