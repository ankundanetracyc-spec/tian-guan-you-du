using Godot;
using Godot.Collections;

/// <summary>阵法编辑器的真实 GraphEdit 画布。只编辑稳定元件 ID、脉纹和显示位置。</summary>
public partial class FormationEditorGraph : GraphEdit
{
    private static readonly Color PulseInk = new("#427c70");
    private static readonly Color PulseGold = new("#b88734");
    private FormationCircuitData? _draft;
    private readonly System.Collections.Generic.Dictionary<string, GraphNode> _graphNodes = [];
    private Dictionary? _selectedWire;
    private bool _binding;
    private bool _hasBoundDraft;

    public event System.Action? DraftEdited;
    public event System.Action<string>? SelectionChanged;
    public System.Func<string, bool>? CanDropNode { get; set; }
    public string SelectedWireText { get; private set; } = "未选中脉纹";

    public override void _Ready()
    {
        MouseFilter = MouseFilterEnum.Stop;
        FocusMode = FocusModeEnum.All;
        ShowGrid = true;
        GridPattern = GridPatternEnum.Dots;
        ShowMenu = false;
        ShowZoomButtons = false;
        ShowGridButtons = false;
        ShowMinimapButton = false;
        MinimapEnabled = false;
        ShowArrangeButton = false;
        RightDisconnects = false;
        PanningScheme = PanningSchemeEnum.Zooms;
        ZoomMin = 0.15f;
        ZoomMax = 1.45f;
        ZoomStep = 1.1f;
        ConnectionLinesCurvature = 0.2f;
        ConnectionLinesThickness = 3f;
        ConnectionLinesAntialiased = true;
        AddValidConnectionType(1, 1);
        ConnectionRequest += connect_requested;
        DisconnectionRequest += disconnect_requested;
        DeleteNodesRequest += delete_requested;
        NodeSelected += node_selected;
        EndNodeMove += node_move_ended;
        AddThemeStyleboxOverride("panel", paper_canvas_style());
    }

    public void BindDraft(FormationCircuitData draft)
    {
        _draft = draft;
        _binding = true;
        _graphNodes.Clear();
        _selectedWire = null;
        ClearConnections();
        foreach (var child in GetChildren())
            if (child is GraphNode graphNode)
            {
                RemoveChild(graphNode);
                graphNode.QueueFree();
            }

        foreach (var node in draft.nodes)
        {
            if (node is null || string.IsNullOrWhiteSpace(node.node_id.ToString())) continue;
            var graphNode = make_graph_node(node);
            _graphNodes[node.node_id.ToString()] = graphNode;
            AddChild(graphNode);
        }
        foreach (var wire in draft.pulse_wires)
        {
            var from = wire.from_node_id.ToString();
            var to = wire.to_node_id.ToString();
            if (_graphNodes.ContainsKey(from) && _graphNodes.ContainsKey(to))
                ConnectNode(from, 0, to, 0, true);
        }
        if (!_hasBoundDraft)
        {
            _hasBoundDraft = true;
            CallDeferred(nameof(center_initial_view));
        }
        _binding = false;
        QueueRedraw();
        SelectionChanged?.Invoke(SelectedWireText);
    }

    public void CenterGraph()
    {
        if (_graphNodes.Count == 0 || Size.X <= 0 || Size.Y <= 0)
        {
            Zoom = 0.82f;
            ScrollOffset = Vector2.Zero;
            return;
        }

        var bounds = new Rect2();
        var hasBounds = false;
        foreach (var graphNode in _graphNodes.Values)
        {
            var nodeSize = graphNode.Size.X > 0 && graphNode.Size.Y > 0
                ? graphNode.Size
                : graphNode.CustomMinimumSize;
            var nodeBounds = new Rect2(graphNode.PositionOffset, nodeSize);
            bounds = hasBounds ? bounds.Merge(nodeBounds) : nodeBounds;
            hasBounds = true;
        }

        var margin = new Vector2(28, 28);
        var available = new Vector2(Mathf.Max(1, Size.X - margin.X * 2), Mathf.Max(1, Size.Y - margin.Y * 2));
        var fitZoom = Mathf.Min(available.X / Mathf.Max(1, bounds.Size.X), available.Y / Mathf.Max(1, bounds.Size.Y));
        Zoom = Mathf.Clamp(fitZoom, ZoomMin, ZoomMax);
        var visibleContent = bounds.Size * Zoom;
        var centeredOrigin = (Size - visibleContent) * 0.5f;
        ScrollOffset = bounds.Position * Zoom - centeredOrigin;
    }

    private async void center_initial_view()
    {
        await ToSignal(GetTree(), SceneTree.SignalName.ProcessFrame);
        CenterGraph();
    }

    public override bool _CanDropData(Vector2 atPosition, Variant data)
    {
        if (_draft is null || data.VariantType != Variant.Type.String) return false;
        var nodeId = data.AsString();
        var accepted = is_supported_id(nodeId) && CanDropNode?.Invoke(nodeId) == true;
        return accepted;
    }

    public override void _DropData(Vector2 atPosition, Variant data)
    {
        if (_draft is null || data.VariantType != Variant.Type.String) return;
        var nodeId = data.AsString();
        if (!is_supported_id(nodeId) || CanDropNode?.Invoke(nodeId) != true) return;

        var graphPosition = (atPosition + ScrollOffset) / Zoom;
        var existing = find_data_node(nodeId);
        if (existing is null)
        {
            var created = FormationV1Catalog.CreateNode(nodeId);
            if (created is null) return;
            _draft.nodes.Add(created);
            existing = created;
        }
        existing.editor_position = snap_position(graphPosition);
        existing.has_editor_position = true;
        BindDraft(_draft);
        DraftEdited?.Invoke();
    }

    public override void _GuiInput(InputEvent @event)
    {
        if (@event is InputEventMouseButton { ButtonIndex: MouseButton.Left, Pressed: true } mouse)
        {
            GrabFocus();
            var connection = GetClosestConnectionAtPoint(mouse.Position, 13f);
            if (connection.Count > 0)
            {
                _selectedWire = connection;
                var from = connection["from_node"].AsStringName().ToString();
                var to = connection["to_node"].AsStringName().ToString();
                SelectedWireText = $"已选脉纹：{display_name(from)} → {display_name(to)}";
                QueueRedraw();
                SelectionChanged?.Invoke(SelectedWireText);
                AcceptEvent();
                return;
            }
            if (_selectedWire is not null)
            {
                _selectedWire = null;
                SelectedWireText = "未选中脉纹";
                QueueRedraw();
                SelectionChanged?.Invoke(SelectedWireText);
            }
        }
        else if (@event is InputEventKey { Pressed: true, Echo: false, Keycode: Key.Delete } && _selectedWire is not null)
        {
            var from = _selectedWire["from_node"].AsStringName();
            var fromPort = (int)_selectedWire["from_port"].AsInt64();
            var to = _selectedWire["to_node"].AsStringName();
            var toPort = (int)_selectedWire["to_port"].AsInt64();
            disconnect_requested(from, fromPort, to, toPort);
            AcceptEvent();
        }
    }

    public void DisconnectSelectedWire()
    {
        if (_selectedWire is null) return;
        disconnect_requested(
            _selectedWire["from_node"].AsStringName(), (int)_selectedWire["from_port"].AsInt64(),
            _selectedWire["to_node"].AsStringName(), (int)_selectedWire["to_port"].AsInt64());
    }

    public void DeleteSelectedNodes()
    {
        if (_draft is null) return;
        var selected = new System.Collections.Generic.List<string>();
        foreach (var node in GetChildren())
            if (node is GraphNode graphNode && graphNode.Selected)
                selected.Add(graphNode.Name.ToString());
        remove_nodes(selected);
    }

    public void FocusValidationIssue(FormationValidationIssue issue)
    {
        if (_draft is null) return;
        if (!string.IsNullOrWhiteSpace(issue.FromNodeId) && !string.IsNullOrWhiteSpace(issue.ToNodeId))
        {
            var wire = _draft.pulse_wires.FirstOrDefault(candidate =>
                candidate.from_node_id.ToString() == issue.FromNodeId && candidate.to_node_id.ToString() == issue.ToNodeId);
            if (wire is not null)
            {
                _selectedWire = new Dictionary
                {
                    ["from_node"] = wire.from_node_id,
                    ["from_port"] = 0,
                    ["to_node"] = wire.to_node_id,
                    ["to_port"] = 0,
                    ["keep_alive"] = true
                };
                SelectedWireText = $"已选脉纹：校验定位 {display_name(issue.FromNodeId)} → {display_name(issue.ToNodeId)}";
                QueueRedraw();
                SelectionChanged?.Invoke(SelectedWireText);
                return;
            }
        }
        if (!string.IsNullOrWhiteSpace(issue.NodeId) && _graphNodes.TryGetValue(issue.NodeId, out var graphNode))
        {
            _selectedWire = null;
            graphNode.Selected = true;
            SetSelected(graphNode);
            SelectedWireText = $"校验元件：{display_name(issue.NodeId)}";
            QueueRedraw();
            SelectionChanged?.Invoke(SelectedWireText);
        }
    }

    public override void _Draw()
    {
        base._Draw();
        if (_selectedWire is null || !_selectedWire.ContainsKey("from_node") || !_selectedWire.ContainsKey("to_node")) return;
        var fromName = _selectedWire["from_node"].AsStringName().ToString();
        var toName = _selectedWire["to_node"].AsStringName().ToString();
        if (!_graphNodes.TryGetValue(fromName, out var from) || !_graphNodes.TryGetValue(toName, out var to)) return;
        var start = graph_viewport_point(from, from.GetOutputPortPosition((int)_selectedWire["from_port"].AsInt64()));
        var end = graph_viewport_point(to, to.GetInputPortPosition((int)_selectedWire["to_port"].AsInt64()));
        var points = GetConnectionLine(start, end);
        if (points.Length > 1) DrawPolyline(points, PulseGold, 6f, true);
    }

    // GraphNode's resolved transform includes offset * Zoom - ScrollOffset,
    // matching the inverse used to turn a drop point back into PositionOffset.
    private Vector2 graph_viewport_point(GraphNode node, Vector2 localPoint)
        => GetGlobalTransformWithCanvas().AffineInverse() * node.GetGlobalTransformWithCanvas() * localPoint;

    private GraphNode make_graph_node(FormationNodeData node)
    {
        var fallback = default_position(node.node_id.ToString());
        var position = node.has_editor_position ? node.editor_position : fallback;
        var graphNode = new GraphNode
        {
            Name = node.node_id.ToString(),
            Title = node.display_name,
            PositionOffset = snap_position(position),
            CustomMinimumSize = new Vector2(178, 104),
            Resizable = false,
            Draggable = true,
            Selectable = true,
            FocusMode = FocusModeEnum.None
        };
        var subtitle = node.kind switch
        {
            FormationNodeData.NodeKind.INPUT => "输入 · 实际支付法力的术法",
            FormationNodeData.NodeKind.COUNTER => $"每 {node.interval} 次脉冲放行 1 次",
            FormationNodeData.NodeKind.ACTUATOR => $"阵能消耗 {node.energy_cost} · 护持 {node.effect_value}",
            _ => "当前首版固定元件"
        };
        var label = new Label
        {
            Text = subtitle,
            AutowrapMode = TextServer.AutowrapMode.WordSmart,
            CustomMinimumSize = new Vector2(148, 40),
            MouseFilter = MouseFilterEnum.Ignore
        };
        label.AddThemeColorOverride("font_color", new Color("#e7dfc4"));
        label.AddThemeFontSizeOverride("font_size", 13);
        graphNode.AddChild(label);
        var hasInput = node.kind != FormationNodeData.NodeKind.INPUT;
        var hasOutput = node.kind != FormationNodeData.NodeKind.ACTUATOR;
        graphNode.SetSlot(0, hasInput, 1, PulseInk, hasOutput, 1, PulseInk);
        graphNode.AddThemeColorOverride("title_color", new Color("#f0d27a"));
        graphNode.AddThemeColorOverride("close_color", new Color("#8fe5d6"));
        graphNode.AddThemeColorOverride("resizer_color", new Color("#8fe5d6"));
        graphNode.AddThemeStyleboxOverride("panel", node_panel_style());
        graphNode.AddThemeStyleboxOverride("titlebar", node_header_style());
        graphNode.AddThemeStyleboxOverride("titlebar_selected", node_header_style(true));
        return graphNode;
    }

    private void connect_requested(StringName fromNode, long fromPort, StringName toNode, long toPort)
    {
        if (_draft is null || _binding) return;
        var from = fromNode.ToString();
        var to = toNode.ToString();
        if (from == to || !_graphNodes.ContainsKey(from) || !_graphNodes.ContainsKey(to)) return;
        if (fromPort != 0 || toPort != 0) return;
        if (_draft.pulse_wires.Any(w => w.from_node_id.ToString() == from && w.to_node_id.ToString() == to)) return;
        ConnectNode(fromNode, (int)fromPort, toNode, (int)toPort, true);
        _draft.pulse_wires.Add(new FormationWireData { from_node_id = fromNode, to_node_id = toNode });
        _selectedWire = null;
        QueueRedraw();
        DraftEdited?.Invoke();
    }

    private void disconnect_requested(StringName fromNode, long fromPort, StringName toNode, long toPort)
    {
        if (_draft is null || _binding) return;
        DisconnectNode(fromNode, (int)fromPort, toNode, (int)toPort);
        var from = fromNode.ToString();
        var to = toNode.ToString();
        for (var i = _draft.pulse_wires.Count - 1; i >= 0; i--)
            if (_draft.pulse_wires[i].from_node_id.ToString() == from && _draft.pulse_wires[i].to_node_id.ToString() == to)
                _draft.pulse_wires.RemoveAt(i);
        _selectedWire = null;
        SelectedWireText = "未选中脉纹";
        QueueRedraw();
        SelectionChanged?.Invoke(SelectedWireText);
        QueueRedraw();
        DraftEdited?.Invoke();
    }

    private void delete_requested(Array<StringName> nodeNames) => remove_nodes(nodeNames.Select(n => n.ToString()).ToList());

    private void remove_nodes(System.Collections.Generic.IEnumerable<string> names)
    {
        if (_draft is null || _binding) return;
        var remove = names.ToHashSet();
        if (remove.Count == 0) return;
        foreach (var nodeId in remove)
        {
            if (_graphNodes.Remove(nodeId, out var graphNode))
            {
                RemoveChild(graphNode);
                graphNode.QueueFree();
            }
        }
        for (var i = _draft.nodes.Count - 1; i >= 0; i--)
            if (remove.Contains(_draft.nodes[i].node_id.ToString())) _draft.nodes.RemoveAt(i);
        for (var i = _draft.pulse_wires.Count - 1; i >= 0; i--)
            if (remove.Contains(_draft.pulse_wires[i].from_node_id.ToString()) || remove.Contains(_draft.pulse_wires[i].to_node_id.ToString()))
                _draft.pulse_wires.RemoveAt(i);
        if (_selectedWire is not null && (remove.Contains(_selectedWire["from_node"].AsStringName().ToString()) || remove.Contains(_selectedWire["to_node"].AsStringName().ToString())))
            _selectedWire = null;
        BindDraft(_draft);
        DraftEdited?.Invoke();
    }

    private void node_move_ended()
    {
        if (_draft is null || _binding) return;
        foreach (var node in _draft.nodes)
            if (_graphNodes.TryGetValue(node.node_id.ToString(), out var graphNode))
            {
                node.editor_position = snap_position(graphNode.PositionOffset);
                node.has_editor_position = true;
                graphNode.PositionOffset = node.editor_position;
            }
        DraftEdited?.Invoke();
    }

    private void node_selected(Node node)
    {
        if (node is GraphNode graphNode)
        {
            _selectedWire = null;
            SelectedWireText = "未选中脉纹";
            QueueRedraw();
            SelectionChanged?.Invoke($"已选元件：{display_name(graphNode.Name.ToString())}");
        }
    }

    private FormationNodeData? find_data_node(string nodeId) => _draft?.nodes.FirstOrDefault(n => n.node_id.ToString() == nodeId);

    private static bool is_supported_id(string nodeId) => nodeId is "spell_input" or "third_spell_counter" or "ward_actuator";
    private static string display_name(string id) => id switch { "spell_input" => "术法感应枢", "third_spell_counter" => "三候枢", "ward_actuator" => "护持阵器", _ => id };
    private static Vector2 default_position(string id) => id switch { "spell_input" => new Vector2(16, 150), "third_spell_counter" => new Vector2(210, 150), "ward_actuator" => new Vector2(404, 150), _ => new Vector2(120, 300) };
    private static Vector2 snap_position(Vector2 point) => new(Mathf.Round(point.X / 20f) * 20f, Mathf.Round(point.Y / 20f) * 20f);

    private static StyleBoxTexture paper_canvas_style()
    {
        var texture = ResourceLoader.Load<Texture2D>("res://textures/ui/world_hud_20261011/paper_panel_v1.png");
        return new StyleBoxTexture
        {
            Texture = texture,
            TextureMarginLeft = 38,
            TextureMarginRight = 38,
            TextureMarginTop = 36,
            TextureMarginBottom = 36,
            ModulateColor = new Color("#d9e2d4"),
            DrawCenter = true,
            ContentMarginLeft = 18,
            ContentMarginRight = 18,
            ContentMarginTop = 16,
            ContentMarginBottom = 16
        };
    }

    private static StyleBoxFlat node_panel_style() => new()
    {
        BgColor = new Color("#263b35"), BorderColor = new Color("#738a77"),
        BorderWidthLeft = 1, BorderWidthTop = 1, BorderWidthRight = 1, BorderWidthBottom = 1,
        CornerRadiusTopLeft = 6, CornerRadiusTopRight = 6, CornerRadiusBottomLeft = 6, CornerRadiusBottomRight = 6,
        ContentMarginLeft = 12, ContentMarginRight = 12, ContentMarginTop = 8, ContentMarginBottom = 8
    };

    private static StyleBoxFlat node_header_style(bool selected = false) => new()
    {
        BgColor = selected ? new Color("#536750") : new Color("#354c43"),
        BorderColor = selected ? PulseGold : new Color("#65776a"),
        BorderWidthLeft = 0, BorderWidthTop = 0, BorderWidthRight = 0, BorderWidthBottom = selected ? 2 : 1,
        ContentMarginLeft = 10, ContentMarginRight = 10, ContentMarginTop = 8, ContentMarginBottom = 6
    };
}

/// <summary>左侧元件条目：Godot 原生 GUI 拖放数据，不直接改阵图。</summary>
public partial class FormationEditorCatalogDragItem : Button
{
    public string NodeId { get; set; } = "";

    public override Variant _GetDragData(Vector2 atPosition)
    {
        if (string.IsNullOrWhiteSpace(NodeId) || Disabled) return default;
        SetDragPreview(make_drag_preview());
        return NodeId;
    }

    private Control make_drag_preview()
    {
        var preview = new PanelContainer { CustomMinimumSize = new Vector2(220, 50) };
        preview.AddChild(new Label { Text = Text, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center });
        return preview;
    }
}
