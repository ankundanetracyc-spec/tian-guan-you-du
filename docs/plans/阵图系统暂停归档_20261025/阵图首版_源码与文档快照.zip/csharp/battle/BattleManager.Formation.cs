using Godot;
using Godot.Collections;

public partial class BattleManager : Node2D
{
    public void emit_formation_event(GodotObject owner, string eventId, string sourceTag, int amplitude = 1)
    {
        foreach (var circuit in _formationCircuits.GetValueOrDefault(owner, [])) circuit.emit(eventId, sourceTag, amplitude);
    }

    /// <summary>即时队列技能只在合法结算并实际支付后记为出招事件。</summary>
    private int PayQueuedSkillAndEmitFormationEvents(GodotObject owner, ActiveSkillData skill)
    {
        var manaBefore = owner.Get("current_mana").AsInt32();
        Pay(owner, skill);
        var manaPaid = Math.Max(0, manaBefore - owner.Get("current_mana").AsInt32());
        emit_formation_event(owner, "card_played", "card");
        if (manaPaid > 0) emit_formation_event(owner, "spell_played", "spell");
        return manaPaid;
    }

    /// <summary>阵器最终只调用已有的战斗效果入口；不伪装成一张手牌，也不支付精力/法力。</summary>
    public void resolve_formation_actuator(GodotObject owner, FormationNodeData actuator)
    {
        var value = Mathf.Max(0, actuator.effect_value);
        switch (actuator.actuator_effect)
        {
            case FormationNodeData.ActuatorEffect.SHIELD:
                var previousShield = owner.Get("shield").AsInt32();
                owner.Set("shield", previousShield + value);
                show_status_gain(owner, "护持", owner.Get("shield").AsInt32() - previousShield);
                break;
            case FormationNodeData.ActuatorEffect.RESTORE_MANA:
                owner.Set("current_mana", Mathf.Min(owner.Get("max_mana").AsInt32(), owner.Get("current_mana").AsInt32() + value));
                break;
            case FormationNodeData.ActuatorEffect.MAGIC_DAMAGE:
                var target = FindTarget(owner);
                if (!GodotObject.IsInstanceValid(target)) return;
                var damage = Mathf.Max(1, BattleActionResolver.apply_defense(value, "magic", target!));
                target!.Set("current_health", Mathf.Max(0, target.Get("current_health").AsInt32() - damage));
                if (target.HasMethod("update_ui")) target.Call("update_ui");
                show_damage_number(target, damage, "magic");
                break;
        }
    }
    public Array<Dictionary> get_formation_snapshot(GodotObject owner)
    {
        var result = new Array<Dictionary>();
        foreach (var circuit in _formationCircuits.GetValueOrDefault(owner, [])) result.Add(circuit.snapshot());
        return result;
    }
    private void initialize_formation_circuits(GodotObject owner, BattleEntityData snapshot)
    {
        // 每次正式战斗都会生成新的参战节点；清理上场对象，避免运行态滞留在旧快照上。
        foreach (var staleOwner in _formationCircuits.Keys.Where(existing =>
            !GodotObject.IsInstanceValid(existing) || !all_units.Contains(existing)).ToArray())
            _formationCircuits.Remove(staleOwner);

        var circuits = new List<FormationCircuitRuntime>();
        foreach (var data in snapshot.formation_circuits)
        {
            if (data is null) continue;
            var validation = FormationCircuitService.Validate(
                data,
                CardRules.Number(owner, "formation_proficiency"),
                snapshot.formation_manual_ids);
            if (!validation.IsValid)
            {
                GD.PushWarning($"阵图 {data.circuit_name} 未载入：{string.Join("；", validation.Issues.Select(issue => issue.Message))}");
                continue;
            }
            circuits.Add(new FormationCircuitRuntime(data, owner, this));
        }
        if (circuits.Count > 0) _formationCircuits[owner] = circuits;
    }
}
