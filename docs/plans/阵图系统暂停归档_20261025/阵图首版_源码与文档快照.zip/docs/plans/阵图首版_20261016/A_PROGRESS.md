# A 进度
- 目标：完成首版阵图数据、校验、装配和深复制；起点：`2ed38422d8f0b6d31671df12c872f45cf6d65d08`，工作树干净。
- 顺序：读策划/契约→公共 API→构建提交→快照复制与烟雾验收；最大风险：Godot Resource/v8 序列化行为。
- 边界：不改运行时、百工 UI、MainScene 或统筹文档。
- 状态：A 分工范围完成；目录强持有模板/节点/阵录，校验不再逐次 ResourceLoader.Load 或复制模板节点。
- 深复制：`BattleEntityData.copy_from`、`Character.apply_battle_data` 和 `Character.get_snapshot_data` 均逐层克隆阵图资源。
- 验收：`dotnet build Stacklands.csproj --no-restore --nologo -v:minimal` 0 警告/错误；隔离 APPDATA 运行 `FormationDataSmoke.tscn` 通过。
- 覆盖：资格/端口/拓扑/硬件/原子装配/幂等/快照复制/v8 往返/旧字段缺省/64次校验跨强制 GC。
- 证据：`tmp/FormationDataSmoke.log`；未触碰正式存档槽。
