param(
    [string]$Engine = 'D:\Godot\gd.net\Godot_v4.7.2-stable_mono_win64_console.exe',
    [switch]$SkipBuild
)
$ErrorActionPreference = 'Stop'
$formationWorkspace = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$formationRunRoot = Join-Path $formationWorkspace ('tmp\formation-journey-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [Guid]::NewGuid().ToString('N').Substring(0, 6))
$formationAppData = Join-Path $formationRunRoot 'Roaming'
New-Item -ItemType Directory -Force -Path $formationAppData | Out-Null
$formationPreviousEnvironment = @{}
foreach ($formationName in @('APPDATA', 'LOCALAPPDATA', 'TEMP', 'TMP')) {
    $formationPreviousEnvironment[$formationName] = [Environment]::GetEnvironmentVariable($formationName, 'Process')
}
Push-Location $formationWorkspace
try {
    if (-not $SkipBuild) {
        & dotnet build .\Stacklands.csproj --no-restore --nologo -v:minimal
        if ($LASTEXITCODE -ne 0) { throw 'Formation journey build failed.' }
    }
    & git rev-parse HEAD | Set-Content -Encoding utf8 (Join-Path $formationRunRoot 'version.txt')
    $env:APPDATA = $formationAppData
    $env:LOCALAPPDATA = Join-Path $formationRunRoot 'Local'
    $env:TEMP = $env:TMP = Join-Path $formationRunRoot 'Temp'
    New-Item -ItemType Directory -Force -Path $env:LOCALAPPDATA, $env:TEMP | Out-Null
    foreach ($formationPhase in @('write', 'read')) {
        $formationOut = Join-Path $formationRunRoot "$formationPhase.stdout.log"
        $formationErr = Join-Path $formationRunRoot "$formationPhase.stderr.log"
        $formationArguments = @('--headless', '--max-fps', '120', '--path', ('"' + $formationWorkspace + '"'), 'res://tools/FormationJourneyAcceptance.tscn', '--', "--phase=$formationPhase", ('"--expected-appdata=' + $formationAppData + '"'))
        $formationProcess = Start-Process -FilePath $Engine -ArgumentList $formationArguments -WindowStyle Hidden -PassThru -RedirectStandardOutput $formationOut -RedirectStandardError $formationErr
        $formationDeadline = [DateTime]::UtcNow.AddMinutes(4)
        while (-not $formationProcess.WaitForExit(1000)) {
            if ([DateTime]::UtcNow -gt $formationDeadline) {
                Get-CimInstance Win32_Process | Where-Object { $_.ParentProcessId -eq $formationProcess.Id -and $_.CommandLine -like '*FormationJourneyAcceptance.tscn*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }
                Stop-Process -Id $formationProcess.Id -Force -ErrorAction SilentlyContinue
                throw "Formation journey $formationPhase timed out. Logs: $formationRunRoot"
            }
        }
        $formationProcess.Refresh()
        Get-Content $formationOut | Where-Object { $_ -like 'FORMATION_JOURNEY*' }
        if ($formationProcess.ExitCode -ne 0 -or -not (Select-String -Path $formationOut -SimpleMatch "FORMATION_JOURNEY_$($formationPhase.ToUpperInvariant()):" -Quiet)) {
            Get-Content $formationErr -Tail 35
            throw "Formation journey $formationPhase failed with exit $($formationProcess.ExitCode). Logs: $formationRunRoot"
        }
    }
    Write-Output "FORMATION_JOURNEY_BOTH_PROCESSES_OK: $formationRunRoot"
}
finally {
    foreach ($formationName in $formationPreviousEnvironment.Keys) {
        [Environment]::SetEnvironmentVariable($formationName, $formationPreviousEnvironment[$formationName], 'Process')
    }
    Pop-Location
}
