param(
    [ValidateSet("1920x1080", "1280x720")]
    [string]$Resolution = "1920x1080"
)

$workspace = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$tmpRoot = Join-Path $workspace "tmp"
$userRoot = Join-Path $tmpRoot "formation-editor-user"
$appData = Join-Path $userRoot "Roaming"
$localAppData = Join-Path $userRoot "Local"
$tempPath = Join-Path $userRoot "Temp"
$logRoot = Join-Path $tmpRoot "formation-editor-logs"
New-Item -ItemType Directory -Force -Path $appData, $localAppData, $tempPath, $logRoot | Out-Null

$env:APPDATA = $appData
$env:LOCALAPPDATA = $localAppData
$env:TEMP = $tempPath
$env:TMP = $tempPath

$engine = "D:\Godot\gd.net\Godot_v4.7.2-stable_mono_win64_console.exe"
$arguments = @("--path", $workspace, "res://tools/FormationEditorSmoke.tscn", "--", "--capture")
if ($Resolution -eq "1280x720") { $arguments += "--compact" }
$stdout = Join-Path $logRoot "$Resolution.stdout.log"
$stderr = Join-Path $logRoot "$Resolution.stderr.log"
$process = Start-Process -FilePath $engine -ArgumentList $arguments -WindowStyle Hidden -PassThru -RedirectStandardOutput $stdout -RedirectStandardError $stderr -Wait
Write-Output "Formation editor smoke at $Resolution exited $($process.ExitCode)"
Get-Content -Tail 60 $stdout
Get-Content -Tail 60 $stderr
if ($process.ExitCode -ne 0) { exit $process.ExitCode }
