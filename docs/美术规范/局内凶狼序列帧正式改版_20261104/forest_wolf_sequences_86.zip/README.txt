Whole-wolf sequence pack / 86 original cels

idle 12; walk 16; trot 16; windup 8; lunge 6; recover 10; hurt 6; death 12.
Source sheets are transparent original PNGs, read in row-major order.
SpriteFrames and five lossless texture resources are in forest_wolf_frames_v2/.
The SpriteFrames resource preserves raw cell pixels. For consistent body size,
ground registration and game timing, use sequence.json with the supplied player.
Each clip uses one fixed sheet density. Individual cels are never stretched.

Godot: instantiate forest_wolf_sequence.gd, set the parent scale to 0.55,
then call build() with the full path to forest_wolf_frames_v2.
Drive set_motion_context(delta, velocity, state, remaining_time, facing, alive).
windup=0.8s, lunge=0.2s, recover=1.5s; art does not own movement or damage.
Five complete image-generation prompts are included next to their PNG sheets.
