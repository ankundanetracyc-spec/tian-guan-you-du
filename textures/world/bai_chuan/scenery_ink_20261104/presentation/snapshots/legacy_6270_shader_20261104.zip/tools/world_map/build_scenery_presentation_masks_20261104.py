"""Build data masks for the native Godot terrain presentation, never gameplay.

The PNGs contain scalar weights, not replacement landscape artwork. The original
6270 painting, its nine exact crops, layout and navigation are read-only inputs.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw
from scipy import ndimage


ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "textures/world/bai_chuan/scenery_ink_20261104/presentation"
ART = ROOT / "textures/world/bai_chuan/free_world_8000_3x3_20261104/master_8000.png"
LAYOUT = ROOT / "resources/world/bai_chuan/free_layout_3x3_20261104.json"
NAVIGATION = ROOT / "resources/world/bai_chuan/free_navigation_3x3_20261104.json"
PLAN = ROOT / "docs/prototypes/百川宗门城镇资源规划数据_20261027.json"
SIZE = 2048
WORLD_SIZE = 7372.8


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def smoothstep(lo, hi, value):
    t = np.clip((value - lo) / (hi - lo), 0.0, 1.0)
    return t * t * (3.0 - 2.0 * t)


def remove_small(mask, minimum):
    labels, _ = ndimage.label(mask)
    counts = np.bincount(labels.ravel())
    accepted = counts >= minimum
    accepted[0] = False
    return accepted[labels]


def save_data(name, channels):
    data = np.clip(np.stack(channels, axis=-1) * 255.0 + 0.5, 0, 255).astype(np.uint8)
    path = OUT / name
    Image.fromarray(data, "RGBA").save(path, optimize=True)
    return {"path": str(path.relative_to(ROOT)).replace("\\", "/"), "sha256": digest(path),
            "size": [SIZE, SIZE], "mode": "RGBA8 scalar data; no sRGB conversion"}


def landmark_field(layout, nodes):
    # Feathered asymmetric oblongs share the surrounding paper tone. They have
    # no opaque white centre, disk rim, shadow, decal, road or icon of their own.
    result = np.zeros((SIZE, SIZE), np.float32)
    scale = SIZE / WORLD_SIZE
    for ident, place in layout["locations"].items():
        node = nodes[ident]
        built = node.get("type") != "wild"
        rx, ry = (92.0, 59.0) if built else (45.0, 34.0)
        cx, cy = place["drawPos"]
        cy -= 13.0 if built else 0.0
        x0, x1 = max(0, int((cx - rx * 2.2) * scale)), min(SIZE, int((cx + rx * 2.2) * scale) + 1)
        y0, y1 = max(0, int((cy - ry * 2.2) * scale)), min(SIZE, int((cy + ry * 2.2) * scale) + 1)
        yy, xx = np.mgrid[y0:y1, x0:x1].astype(np.float32)
        dx, dy = (xx / scale - cx) / rx, (yy / scale - cy) / ry
        # The broad irregular feather avoids a visible repeated ellipse.
        phase = int(hashlib.sha256(ident.encode()).hexdigest()[:8], 16) / 0xFFFFFFFF * np.pi * 2
        q = (dx + 0.12 * dy) ** 2 + dy ** 2
        feather = np.exp(-q * 1.55) * (0.94 + 0.06 * np.sin(dx * 3.1 + dy * 2.2 + phase))
        result[y0:y1, x0:x1] = np.maximum(result[y0:y1, x0:x1], feather * (0.94 if built else 0.62))
    return result


def regional_fields(plan, water, grove):
    # Existing natural-area polygons are only colour guidance. The 5% world
    # feather removes polygon edges; their old river/ridge geometry is ignored.
    weights = {
        "镇岳西岭": (0.14, 0.86, 0.06), "玄都台原": (0.04, 1.00, 0.09),
        "归藏盆地": (0.24, 0.54, 0.15), "涵虚水乡": (0.38, 0.08, 0.74),
        "沧溟河港": (0.14, 0.17, 0.90), "玉虚叠嶂": (0.76, 0.28, 0.12),
        "百药南林": (1.00, 0.08, 0.15), "古寺东陵": (0.11, 0.65, 0.27),
        "幽泉深谷": (0.48, 0.15, 0.74),
    }
    total = np.zeros((SIZE, SIZE), np.float32)
    fields = np.zeros((3, SIZE, SIZE), np.float32)
    for area in plan["terrainPlanning"]["areas"]:
        mask = Image.new("L", (SIZE, SIZE), 0)
        points = [(x * SIZE / 100.0, y * SIZE / 100.0) for x, y in area["polygon"]]
        ImageDraw.Draw(mask).polygon(points, fill=255)
        feather = ndimage.gaussian_filter(np.asarray(mask).astype(np.float32) / 255.0, SIZE * 0.035)
        for channel, weight in enumerate(weights[area["name"]]):
            fields[channel] += feather * weight
        total += feather
    # Where the old planning polygons have gaps, gently extend their palette;
    # never draw their outlines or invent corresponding playable terrain.
    fields /= np.maximum(total, 0.28)
    bank = np.exp(-ndimage.distance_transform_edt(water < 0.25) / (SIZE * 0.009))
    fields[2] = np.maximum(fields[2] * 0.88, bank * 0.72)
    return [np.clip(field, 0.0, 1.0) for field in fields] + [grove]


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    inputs = {str(path.relative_to(ROOT)).replace("\\", "/"): digest(path)
              for path in (ART, LAYOUT, NAVIGATION, PLAN)}
    layout = json.loads(LAYOUT.read_text(encoding="utf-8"))
    plan = json.loads(PLAN.read_text(encoding="utf-8"))
    assert layout["worldSize"] == WORLD_SIZE and len(layout["locations"]) == 123
    nodes = {node["id"]: node for node in plan["nodes"]}
    with Image.open(ART) as source:
        assert source.size == (6270, 6270)
        rgb = np.asarray(source.convert("RGB").resize((SIZE, SIZE), Image.Resampling.BOX), dtype=np.float32) / 255.0
    r, g, b = np.moveaxis(rgb, -1, 0)
    lum = rgb @ np.array([0.2126, 0.7152, 0.0722], np.float32)
    water = smoothstep(0.055, 0.105, b - r) * smoothstep(0.012, 0.035, b - g)
    water = ndimage.gaussian_filter(water, 0.42)
    dry = water < 0.15

    # Protect connected ink masses and their pale interiors. Flat paper grain
    # lacks the local density required to seed a protected mountain/woodland.
    density = ndimage.uniform_filter(((lum < 0.705) & dry).astype(np.float32), size=7)
    mass = remove_small((density > 0.16) & dry, 20)
    mass = ndimage.binary_fill_holes(ndimage.binary_closing(mass, iterations=3))
    mass = ndimage.binary_dilation(mass, iterations=2)
    protection = ndimage.gaussian_filter(mass.astype(np.float32), 1.7)
    # Never suppress a prominent dark source stroke even outside mass seeds.
    protection = np.maximum(protection, (1.0 - smoothstep(0.55, 0.73, lum)) * dry)
    protection = np.maximum(protection, np.exp(-ndimage.distance_transform_edt(water < 0.25) / 1.6) * 0.92)

    grove_seed = (g - b > 0.025) & (lum < 0.69) & (g - r > 0.012) & dry
    grove_density = ndimage.uniform_filter(grove_seed.astype(np.float32), size=7)
    grove = ndimage.gaussian_filter(smoothstep(0.07, 0.38, grove_density), 1.5) * dry
    # B is a low-frequency luminance measurement, not a colour image. It lets
    # the shader reduce flat-ground contrast without filtering source rock ink.
    paper_luminance = ndimage.gaussian_filter(lum, 7.0)
    clearing = landmark_field(layout, nodes) * (1.0 - water)
    terrain = save_data("terrain_presentation_data.png", [water, protection, paper_luminance, clearing])
    region_channels = regional_fields(plan, water, grove)
    regional = save_data("regional_presentation_data.png", region_channels)
    # A diagnostic of scalar fields only, never a modified copy of the artwork.
    diagnostic = Image.new("RGB", (1024, 1024))
    for channel, offset in ((protection, (0, 0)), (water, (512, 0)), (clearing, (0, 512))):
        panel = Image.fromarray(np.clip(channel * 255, 0, 255).astype(np.uint8), "L")
        diagnostic.paste(panel.resize((512, 512), Image.Resampling.BOX).convert("RGB"), offset)
    regional_rgb = np.stack(region_channels[:3], axis=-1)
    panel = Image.fromarray(np.clip(regional_rgb * 255, 0, 255).astype(np.uint8), "RGB")
    diagnostic.paste(panel.resize((512, 512), Image.Resampling.BOX), (512, 512))
    ImageDraw.Draw(diagnostic).text((10, 10), "SOURCE MASS PROTECTION", fill="#ff5830")
    ImageDraw.Draw(diagnostic).text((522, 10), "NATIVE WATER COVERAGE", fill="#ff5830")
    ImageDraw.Draw(diagnostic).text((10, 522), "EXISTING 123 ANCHORS", fill="#ff5830")
    ImageDraw.Draw(diagnostic).text((522, 522), "GREEN / EARTH / COOL WEIGHTS", fill="#ff5830")
    diagnostic.save(OUT / "mask_diagnostic.png", optimize=True)
    manifest = {
        "version": 1, "purpose": "Native Godot display-only scalar masks. No gameplay consumer.",
        "world_size": WORLD_SIZE, "world_km": 8000.0, "named_locations": 123,
        "source_art_pixels": [6270, 6270], "mask_pixels": [SIZE, SIZE],
        "sampling": "clamp((tile_origin + UV * tile_size) / map_size, 0, 1); linear; repeat disabled; not sRGB",
        "inputs_sha256": inputs, "generator_sha256": digest(Path(__file__)),
        "files": [terrain, regional],
        "channels": {
            "terrain_presentation_data.png": {"R": "water coverage from source blue chroma; shader checks native texel again",
                "G": "preserve connected rock/woodland ink masses, pale interiors, dark contours and banks",
                "B": "7 mask-pixel Gaussian source luminance measurement for flat-ground contrast compression",
                "A": "123 existing named-location soft asymmetric clearing weights; not a white decal"},
            "regional_presentation_data.png": {"R": "green wash from existing Yuxu/Baiyao woodland/valley regions",
                "G": "earth wash from existing western/northern/eastern rock/highland regions",
                "B": "cool grey wash from existing water/valley regions plus actual source-bank proximity",
                "A": "native source woodland tendency from warm-green dark crown clusters"},
        },
        "rules": {"source_resampling": "Only logical measurements use BOX reduction. Original art and nine tiles are never written or resampled.",
            "protection": "Local dark density >0.16 over 7x7 at 2048; connected components >=20; close/fill/dilate and feather; native dark lines remain protected.",
            "regions": "Nine existing terrainPlanning.areas polygons, 3.5% world Gaussian feather; artistic weights only. Original planning waters/ridges are not applied.",
            "clearings": "Built 92x59 world-unit e-folding field, wild 45x34; feathered, asymmetric, low opacity, same nearby paper tone; water excluded.",
            "navigation": "Input SHA recorded only. No navigation/layout/path writes and no playable climate/terrain definitions."},
        "coverage": {"water_mean": float(water.mean()), "protected_mean": float(protection.mean()),
            "clearings_mean": float(clearing.mean()), "grove_mean": float(grove.mean())},
    }
    # Data PNG imports must retain literal scalar values in all four channels.
    for file in (terrain, regional):
        png = OUT / Path(file["path"]).name
        import_path = png.with_suffix(png.suffix + ".import")
        if import_path.exists():
            text = import_path.read_text(encoding="utf-8")
            import_path.write_text(text.replace("process/fix_alpha_border=true", "process/fix_alpha_border=false"), encoding="utf-8")
    (OUT / "mask_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    # Prove the read-only art/geography inputs remained untouched.
    assert all(digest(ROOT / path) == sha for path, sha in inputs.items())
    print(json.dumps({"mask_size": SIZE, "inputs_unchanged": True, "coverage": manifest["coverage"],
                      "files": manifest["files"]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
